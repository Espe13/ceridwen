"""
SVD-accelerated Composite Stellar Population basis.

This module provides ``SVDCSPBasis``, a drop-in replacement for ``CSPBasis``
that compresses both the SSP spectral library and the CLOUDY nebular grids
via truncated Singular Value Decomposition (SVD).

Two independent SVDs are used:

1. **Stellar SVD**: compresses the SSP flux tensor (n_z, n_age, n_wave).
   This accelerates the weighted-sum einsum and the dust mixing-matrix
   algebra.

2. **Nebular SVD**: compresses the pre-evaluated CLOUDY nebular spectrum
   (continuum + lines) at all grid nodes.  This replaces the expensive
   per-evaluation trilinear interpolation on (nspec,)-vectors and the
   Gaussian line projection matmul with interpolation on (k_neb,)-vectors
   and a single final reconstruction.

Keeping the two bases separate avoids the large errors that arise from
projecting narrow emission lines through a stellar SVD basis (which is
optimised for smooth continua).

Usage
-----
    >>> from ceridwen.csp.csp_svd import SVDCSPBasis
    >>> csp = SVDCSPBasis(
    ...     SSPData=ssp_data, theta=theta,
    ...     n_svd_components=10,        # stellar SVD rank
    ...     n_neb_svd_components=20,    # nebular SVD rank
    ... )
    >>> spectrum = csp.get_spectrum(theta)

Author: Amanda Stoffers
"""

import jax.numpy as jnp
from jax import jit, vmap

from ceridwen.csp.csp import CSPBasis


# =========================================================================
# SVDCSPBasis
# =========================================================================

class SVDCSPBasis(CSPBasis):
    """
    SVD-compressed Composite Stellar Population basis.

    Parameters
    ----------
    n_svd_components : int, optional
        Number of singular vectors for the stellar SSP SVD.  Default 10.
    n_neb_svd_components : int, optional
        Number of singular vectors for the nebular CLOUDY SVD.  Default 20.
        Nebular spectra contain narrow emission lines, so they require
        more components than the smooth stellar continua.
    use_svd : bool, optional
        If True (default), use the SVD-compressed forward model.
        If False, fall back to the standard CSPBasis computation.
    svd_variance_threshold : float or None, optional
        If set, overrides ``n_svd_components`` for the stellar SVD.
    neb_svd_variance_threshold : float or None, optional
        If set, overrides ``n_neb_svd_components`` for the nebular SVD.
    **kwargs
        All remaining arguments forwarded to ``CSPBasis.__init__``.
    """

    def __init__(
        self,
        *args,
        n_svd_components=10,
        n_neb_svd_components=20,
        use_svd=True,
        svd_variance_threshold=None,
        neb_svd_variance_threshold=None,
        **kwargs,
    ):
        # Initialise the parent -- this sets self.flux, self.wave,
        # self.neb (NebularModel), etc.
        super().__init__(*args, **kwargs)

        self.use_svd = use_svd
        if not use_svd:
            return

        self._build_stellar_svd(n_svd_components, svd_variance_threshold)

        self._has_neb_svd = False
        if hasattr(self, 'neb'):
            self._build_nebular_svd(n_neb_svd_components,
                                    neb_svd_variance_threshold)

        self._orig_get_spectrum = self.get_spectrum
        self._rewire_spectrum_methods()

    # ===================================================================
    # Stellar SVD construction
    # ===================================================================

    def _build_stellar_svd(self, n_svd_components, svd_variance_threshold):
        """Compute truncated SVD of the SSP flux grid."""
        n_z, n_age, n_wave = self.flux.shape
        F = self.flux.reshape(n_z * n_age, n_wave)

        U, S, Vt = jnp.linalg.svd(F, full_matrices=False)

        if svd_variance_threshold is not None:
            cumvar = jnp.cumsum(S ** 2)
            totvar = cumvar[-1]
            k = int(jnp.searchsorted(cumvar / totvar, svd_variance_threshold)) + 1
            k = max(k, 1)
            self._svd_k = k
            print(
                f"Stellar SVD: variance threshold {svd_variance_threshold} -> "
                f"k = {k} (captures {float(cumvar[k-1]/totvar)*100:.4f}%)"
            )
        else:
            k = min(n_svd_components, min(n_z * n_age, n_wave))
            self._svd_k = k
            cumvar = jnp.cumsum(S ** 2)
            totvar = cumvar[-1]
            print(
                f"Stellar SVD: k = {k} "
                f"(captures {float(cumvar[k-1]/totvar)*100:.4f}%)"
            )

        self._svd_coeffs = (U[:, :k] * S[None, :k]).reshape(n_z, n_age, k)
        self._svd_basis  = Vt[:k, :]
        self._svd_S      = S[:k]
        self._svd_S_full = S
        self._svd_V      = Vt[:k, :].T   # (n_wave, k)

    # ===================================================================
    # Nebular SVD construction
    # ===================================================================

    def _build_nebular_svd(self, n_neb_svd_components,
                           neb_svd_variance_threshold):
        """
        Pre-evaluate the total nebular spectrum (continuum + lines) at
        every CLOUDY grid node and compress via a separate SVD.

        Rather than calling neb.evaluate() via vmap at runtime (trilinear
        interpolation on nspec-vectors plus a gaussnebarr @ line_lum matmul
        ~360 times), the total spectrum is pre-evaluated at all grid nodes
        during __init__ and SVD-compressed, so runtime only interpolates
        k_neb-dimensional coefficient vectors.
        """
        import numpy as np

        neb = self.neb
        nspec  = neb.nspec
        nz     = neb.nebnz
        nage   = neb.nebnage
        nu     = neb.nebnip

        # Pre-evaluate total nebular spectrum at every grid node
        cont_cube = np.array(neb.nebem_cont)   # (nspec, nz, nage, nu)
        line_cube = np.array(neb.nebem_line)   # (nlines, nz, nage, nu)
        gauss     = np.array(neb.gaussnebarr)  # (nspec, nlines)

        n_nodes = nz * nage * nu
        total_spec = np.zeros((n_nodes, nspec))

        idx = 0
        for iz in range(nz):
            for ia in range(nage):
                for iu in range(nu):
                    cont = 10.0 ** cont_cube[:, iz, ia, iu]
                    line_lum = 10.0 ** line_cube[:, iz, ia, iu]
                    line_spec = gauss @ line_lum
                    total_spec[idx] = cont + line_spec
                    idx += 1

        U, S, Vt = np.linalg.svd(total_spec, full_matrices=False)
        cumvar = np.cumsum(S ** 2)
        totvar = cumvar[-1]

        if neb_svd_variance_threshold is not None:
            k = int(np.searchsorted(cumvar / totvar,
                                    neb_svd_variance_threshold)) + 1
            k = max(k, 1)
            print(
                f"Nebular SVD: variance threshold "
                f"{neb_svd_variance_threshold} -> k = {k} "
                f"(captures {cumvar[k-1]/totvar*100:.4f}%)"
            )
        else:
            k = min(n_neb_svd_components, min(n_nodes, nspec))
            print(
                f"Nebular SVD: k = {k} "
                f"(captures {cumvar[k-1]/totvar*100:.4f}%)"
            )

        self._neb_svd_k = k

        coeffs = (U[:, :k] * S[None, :k])   # (n_nodes, k)
        self._neb_svd_coeffs_cube = jnp.array(
            coeffs.reshape(nz, nage, nu, k)
        )
        self._neb_svd_basis = jnp.array(Vt[:k, :])   # (k_neb, nspec)
        self._neb_svd_S = jnp.array(S[:k])
        self._neb_svd_S_full = jnp.array(S)

        # Store the CLOUDY grid coordinate arrays for interpolation
        self._neb_logz_grid = neb.nebem_logz
        self._neb_logu_grid = neb.nebem_logu
        self._neb_age_grid  = neb.nebem_age

        self._has_neb_svd = True

        orig_mb = (cont_cube.nbytes + line_cube.nbytes) / 1024**2
        svd_mb = (self._neb_svd_coeffs_cube.nbytes +
                  self._neb_svd_basis.nbytes) / 1024**2
        print(f"Nebular SVD: {orig_mb:.2f} MB -> {svd_mb:.4f} MB "
              f"({svd_mb/orig_mb*100:.1f}%)")

    # ===================================================================
    # Nebular SVD evaluation helpers
    # ===================================================================

    def _neb_svd_interpolate_coeffs(self, logZ, logU, logage, logQ):
        """
        Trilinear interpolation on the nebular SVD coefficient cube.

        Returns (k_neb,) vector: the SVD coefficients for the total
        nebular spectrum, scaled by Q.

        Cost: 8 gathers of (k_neb,) vectors + weighted sum.
        Compare to standard path: 8 gathers of (nspec,) vectors
        + (nspec, nlines) @ (nlines,) matmul.
        """
        from ceridwen.neb.NebularGridModel import _locate

        z1 = _locate(logZ, self._neb_logz_grid)
        dz = jnp.clip(
            (logZ - self._neb_logz_grid[z1])
            / (self._neb_logz_grid[z1 + 1] - self._neb_logz_grid[z1]),
            0.0, 1.0,
        )
        u1 = _locate(logU, self._neb_logu_grid)
        du = jnp.clip(
            (logU - self._neb_logu_grid[u1])
            / (self._neb_logu_grid[u1 + 1] - self._neb_logu_grid[u1]),
            0.0, 1.0,
        )
        a1 = _locate(logage, self._neb_age_grid)
        da = jnp.clip(
            (logage - self._neb_age_grid[a1])
            / (self._neb_age_grid[a1 + 1] - self._neb_age_grid[a1]),
            0.0, 1.0,
        )

        cube = self._neb_svd_coeffs_cube  # (nz, nage, nu, k_neb)

        w = jnp.array([
            (1 - dz) * (1 - da) * (1 - du),
            (1 - dz) * (1 - da) * (du),
            (1 - dz) * (da) * (1 - du),
            (1 - dz) * (da) * (du),
            (dz) * (1 - da) * (1 - du),
            (dz) * (1 - da) * (du),
            (dz) * (da) * (1 - du),
            (dz) * (da) * (du),
        ])  # (8,)

        corners = jnp.stack([
            cube[z1, a1, u1],
            cube[z1, a1, u1 + 1],
            cube[z1, a1 + 1, u1],
            cube[z1, a1 + 1, u1 + 1],
            cube[z1 + 1, a1, u1],
            cube[z1 + 1, a1, u1 + 1],
            cube[z1 + 1, a1 + 1, u1],
            cube[z1 + 1, a1 + 1, u1 + 1],
        ], axis=0)  # (8, k_neb)

        coeffs_per_Q = jnp.sum(w[:, None] * corners, axis=0)  # (k_neb,)
        Q = 10.0 ** logQ
        return coeffs_per_Q * Q  # (k_neb,)

    def _evaluate_nebular_svd(self, theta):
        """
        Evaluate all nebular contributions using the SVD fast path.

        Returns
        -------
        neb_coeffs_all : (n_z, n_age, k_neb)
            SVD coefficients of the nebular spectrum for each (Z, age).
            Zeros for old ages (> 21 Myr).
        """
        logZ_gas = theta["gas_logz"]
        logU     = theta["gas_logu"]

        def neb_one_svd(logage, logQ):
            return self._neb_svd_interpolate_coeffs(
                logZ_gas, logU, logage, logQ
            )

        # vmap over young ages and metallicities
        # neb_coeffs_y: (n_z, n_young, k_neb)
        neb_coeffs_y = vmap(
            lambda logQ_row: vmap(neb_one_svd)(
                self._neb_ages_young, logQ_row
            )
        )(self._neb_logqq_young)

        # gas_logz and gas_logu are shape-(1,) arrays, so the vmap
        # result carries an extra length-1 axis: (n_z, n_young, 1, k_neb).
        # Squeeze it out, mirroring the [..., 0] pattern in csp.py.
        if neb_coeffs_y.ndim == 4:
            neb_coeffs_y = neb_coeffs_y[..., 0, :]

        # Scatter into full (n_z, n_age, k_neb) array
        n_z = self._n_z
        n_age = self._n_age
        k_neb = self._neb_svd_k
        neb_coeffs_all = jnp.zeros((n_z, n_age, k_neb),
                                   dtype=neb_coeffs_y.dtype)
        neb_coeffs_all = neb_coeffs_all.at[
            :, self._neb_young_idx, :
        ].set(neb_coeffs_y)

        return neb_coeffs_all

    # ===================================================================
    # Method rewiring
    # ===================================================================

    def _rewire_spectrum_methods(self):
        """Replace get_spectrum with SVD-accelerated versions."""
        method_name = self.get_spectrum.__name__

        svd_mapping = {
            'get_spectrum_dattn_nodem_neb':     self._svd_get_spectrum_dattn_nodem_neb,
            'get_spectrum_dattn_nodem_noneb':   self._svd_get_spectrum_dattn_nodem_noneb,
            'get_spectrum_nodattn_nodem_noneb': self._svd_get_spectrum_nodattn_nodem_noneb,
            'get_spectrum_nodattn_nodem_neb':   self._svd_get_spectrum_nodattn_nodem_neb,
            'get_spectrum_dattn_dem_neb':       self._svd_get_spectrum_dattn_dem_neb,
            'get_spectrum_dattn_dem_noneb':     self._svd_get_spectrum_dattn_dem_noneb,
        }

        if method_name in svd_mapping:
            self.get_spectrum = svd_mapping[method_name]
            print(f"SVD: rewired {method_name} -> SVD-accelerated version")
        else:
            print(f"SVD: WARNING -- no SVD implementation for {method_name}, "
                  f"falling back to full-rank computation")
            self.use_svd = False

    def toggle_svd(self, use_svd=None):
        """Toggle between SVD-compressed and full-rank forward models."""
        if use_svd is None:
            use_svd = not self.use_svd
        if use_svd and not self.use_svd:
            self._rewire_spectrum_methods()
        elif not use_svd and self.use_svd:
            self.get_spectrum = self._orig_get_spectrum
        self.use_svd = use_svd
        return self.use_svd

    # ===================================================================
    # Diagnostics
    # ===================================================================

    def svd_diagnostics(self):
        """Return stellar SVD compression diagnostics."""
        n_z, n_age, n_wave = self.flux.shape
        k = self._svd_k

        reconstructed = jnp.einsum(
            "zak,kw->zaw", self._svd_coeffs, self._svd_basis
        )
        residual = self.flux - reconstructed

        rms_orig = jnp.sqrt(jnp.mean(self.flux ** 2))
        rms_err  = jnp.sqrt(jnp.mean(residual ** 2))

        cumvar = jnp.cumsum(self._svd_S_full ** 2)
        totvar = cumvar[-1]

        result = {
            'k': k,
            'singular_values': self._svd_S,
            'variance_explained': float(cumvar[k - 1] / totvar),
            'reconstruction_error_rms': float(rms_err / rms_orig),
            'max_abs_error': float(jnp.max(jnp.abs(residual))),
        }

        if self._has_neb_svd:
            neb_cumvar = jnp.cumsum(self._neb_svd_S_full ** 2)
            neb_totvar = neb_cumvar[-1]
            k_neb = self._neb_svd_k
            result['neb_k'] = k_neb
            result['neb_variance_explained'] = float(
                neb_cumvar[k_neb - 1] / neb_totvar
            )

        return result

    # ===================================================================
    # SVD-accelerated spectrum methods: NO NEBULAR
    # ===================================================================

    def _svd_get_spectrum_nodattn_nodem_noneb(self, theta):
        """Stellar continuum only -- no dust, no nebular."""
        W = self.calculate_ssp_weights(theta=theta)
        c = jnp.einsum("za,zak->k", W, self._svd_coeffs)
        return c @ self._svd_basis

    def _svd_get_spectrum_dattn_nodem_noneb(self, theta):
        """Dust attenuation, no nebular, no dust emission."""
        W = self.calculate_ssp_weights(theta)

        attn, attn_diffuse = self.attenuate_dust(self.wave, theta)
        M       = self._age_bin_mix.astype(attn.dtype)
        tau_age = jnp.einsum("ab,bw->aw", M, attn)
        attn_age = jnp.exp(-tau_age)

        # k x k attenuation mixing matrix per age bin
        attn_basis = self._svd_basis[None, :, :] * attn_age[:, None, :]
        A = jnp.einsum("akw,wj->akj", attn_basis, self._svd_V)

        dusty_coeffs = jnp.einsum("zak,akj->zaj", self._svd_coeffs, A)
        c = jnp.einsum("za,zak->k", W, dusty_coeffs)

        spectrum = c @ self._svd_basis
        spectrum = spectrum * jnp.exp(-attn_diffuse)
        return spectrum.reshape((-1,))

    def _svd_get_spectrum_dattn_dem_noneb(self, theta):
        """Dust attenuation + dust emission, no nebular."""
        W = self.calculate_ssp_weights(theta)

        c_free = jnp.einsum("za,zak->k", W, self._svd_coeffs)
        spectrum_dust_free = c_free @ self._svd_basis

        attn, attn_diffuse = self.attenuate_dust(self.wave, theta)
        M             = self._age_bin_mix.astype(attn.dtype)
        tau_age       = jnp.einsum("ab,bw->aw", M, attn)
        attn_age      = jnp.exp(-tau_age)
        diffuse_curve = jnp.exp(-attn_diffuse)

        attn_basis = self._svd_basis[None, :, :] * attn_age[:, None, :]
        A = jnp.einsum("akw,wj->akj", attn_basis, self._svd_V)
        dusty_coeffs = jnp.einsum("zak,akj->zaj", self._svd_coeffs, A)
        c_attn = jnp.einsum("za,zak->k", W, dusty_coeffs)
        attenuated = (c_attn @ self._svd_basis) * diffuse_curve

        dust_emi_spectrum, _, _ = self.dust_emi.compute_dust_emission(
            spec_attn=attenuated, spec_dustfree=spectrum_dust_free,
            spec_lambda=self.wave, diffuse_curve=diffuse_curve,
            duste_qpah=theta["duste_qpah"],
            duste_umin=theta["duste_umin"],
            duste_gamma=theta["duste_gamma"],
        )
        return dust_emi_spectrum

    # ===================================================================
    # SVD-accelerated spectrum methods: WITH NEBULAR
    #
    # Architecture: stellar and nebular SVDs are kept separate.
    #   - Stellar: weighted sum in k_stellar-dimensional space, then
    #     reconstruct to wavelength space.
    #   - Nebular: vmap over k_neb-dimensional coefficients (fast),
    #     then weighted sum in k_neb space, then reconstruct.
    #   - Final spectrum = stellar_spectrum + nebular_spectrum,
    #     each reconstructed independently in wavelength space.
    #   - Dust attenuation is applied in wavelength space after
    #     reconstruction (since it couples both components).
    # ===================================================================

    def _svd_get_spectrum_nodattn_nodem_neb(self, theta):
        """Nebular emission, no dust."""
        W = self.calculate_ssp_weights(theta=theta)

        # kill_ion only affects young ages at lambda < 912A, so rather than
        # building a per-age kill-ion projection in SVD space, reconstruct the
        # stellar spectrum, then subtract the ionising contribution of the
        # young ages (computed separately and masked to lambda < 912A).
        stellar_coeffs = jnp.einsum("za,zak->k", W, self._svd_coeffs)
        stellar_spec = stellar_coeffs @ self._svd_basis   # (n_wave,)

        young_W = W[:, self._neb_young_idx]  # (n_z, n_young)
        young_coeffs = self._svd_coeffs[:, self._neb_young_idx, :]  # (n_z, n_young, k)
        young_stellar = jnp.einsum("za,zak->k", young_W, young_coeffs)
        young_stellar_spec = young_stellar @ self._svd_basis  # (n_wave,)

        ion_correction = jnp.where(self.ion_mask, young_stellar_spec, 0.0)
        stellar_final = stellar_spec - ion_correction

        # Nebular contribution via SVD fast path
        neb_coeffs_all = self._evaluate_nebular_svd(theta)  # (n_z, n_age, k_neb)
        neb_c = jnp.einsum("za,zak->k", W, neb_coeffs_all)  # (k_neb,)
        neb_spec = neb_c @ self._neb_svd_basis                # (n_wave,)

        return stellar_final + neb_spec

    def _svd_get_spectrum_dattn_nodem_neb(self, theta):
        """Dust attenuation + nebular emission, no dust emission."""
        W = self.calculate_ssp_weights(theta=theta)

        # --- Stellar contribution (dust-attenuated) via stellar SVD ---
        attn, attn_diffuse = self.attenuate_dust(self.wave, theta)
        M       = self._age_bin_mix.astype(attn.dtype)
        tau_age = jnp.einsum("ab,bw->aw", M, attn)
        attn_age = jnp.exp(-tau_age)

        # Attenuated stellar SVD coefficients via mixing matrix
        attn_basis = self._svd_basis[None, :, :] * attn_age[:, None, :]
        A = jnp.einsum("akw,wj->akj", attn_basis, self._svd_V)
        dusty_stellar_coeffs = jnp.einsum(
            "zak,akj->zaj", self._svd_coeffs, A
        )

        # Full stellar (attenuated), minus the young-age ionising correction.
        c_stellar = jnp.einsum("za,zak->k", W, dusty_stellar_coeffs)
        stellar_spec = c_stellar @ self._svd_basis

        young_W = W[:, self._neb_young_idx]
        young_dusty = dusty_stellar_coeffs[:, self._neb_young_idx, :]
        young_c = jnp.einsum("za,zak->k", young_W, young_dusty)
        young_spec = young_c @ self._svd_basis
        ion_correction = jnp.where(self.ion_mask, young_spec, 0.0)
        stellar_final = stellar_spec - ion_correction

        # --- Nebular contribution (dust-attenuated) via nebular SVD ---
        neb_coeffs_all = self._evaluate_nebular_svd(theta)
        neb_c = jnp.einsum("za,zak->k", W, neb_coeffs_all)
        neb_spec_unattenuated = neb_c @ self._neb_svd_basis

        # Per-age dust attenuation of the nebular spectrum: each age's nebular
        # spectrum must be attenuated individually, then summed,
        #   neb_attn_spec = sum_{z,a} W[z,a] * neb_spec[z,a,:] * attn[a,:]
        # so reconstruct per-age nebular spectra, attenuate, and resum.  This
        # O(n_age * n_wave) cost is incurred only for the young ages
        # (n_young ~ 30), much cheaper than the original vmap over CLOUDY.
        neb_weighted = jnp.einsum("za,zak->ak", W, neb_coeffs_all)
        neb_per_age = neb_weighted @ self._neb_svd_basis  # (n_age, n_wave)
        neb_spec_attenuated = jnp.sum(neb_per_age * attn_age, axis=0)

        # Apply diffuse dust to both
        diffuse_curve = jnp.exp(-attn_diffuse)
        spectrum = (stellar_final + neb_spec_attenuated) * diffuse_curve
        return spectrum.reshape((-1,))

    def _svd_get_spectrum_dattn_dem_neb(self, theta):
        """Dust attenuation + nebular + dust emission."""
        W = self.calculate_ssp_weights(theta=theta)

        attn, attn_diffuse = self.attenuate_dust(self.wave, theta)
        M             = self._age_bin_mix.astype(attn.dtype)
        tau_age       = jnp.einsum("ab,bw->aw", M, attn)
        attn_age      = jnp.exp(-tau_age)
        diffuse_curve = jnp.exp(-attn_diffuse)

        # --- Dust-free spectrum ---
        # Stellar (dust-free, with ion correction)
        c_stellar_free = jnp.einsum("za,zak->k", W, self._svd_coeffs)
        stellar_free = c_stellar_free @ self._svd_basis

        young_W = W[:, self._neb_young_idx]
        young_coeffs = self._svd_coeffs[:, self._neb_young_idx, :]
        young_c_free = jnp.einsum("za,zak->k", young_W, young_coeffs)
        young_free = young_c_free @ self._svd_basis
        ion_corr_free = jnp.where(self.ion_mask, young_free, 0.0)
        stellar_free_final = stellar_free - ion_corr_free

        # Nebular (dust-free)
        neb_coeffs_all = self._evaluate_nebular_svd(theta)
        neb_c = jnp.einsum("za,zak->k", W, neb_coeffs_all)
        neb_free = neb_c @ self._neb_svd_basis

        spectrum_dust_free = stellar_free_final + neb_free

        # --- Attenuated spectrum ---
        # Stellar (attenuated)
        attn_basis = self._svd_basis[None, :, :] * attn_age[:, None, :]
        A_mat = jnp.einsum("akw,wj->akj", attn_basis, self._svd_V)
        dusty_stellar = jnp.einsum("zak,akj->zaj", self._svd_coeffs, A_mat)
        c_stellar_attn = jnp.einsum("za,zak->k", W, dusty_stellar)
        stellar_attn = c_stellar_attn @ self._svd_basis

        young_dusty = dusty_stellar[:, self._neb_young_idx, :]
        young_c_attn = jnp.einsum("za,zak->k", young_W, young_dusty)
        young_attn = young_c_attn @ self._svd_basis
        ion_corr_attn = jnp.where(self.ion_mask, young_attn, 0.0)
        stellar_attn_final = stellar_attn - ion_corr_attn

        # Nebular (attenuated per-age)
        neb_weighted = jnp.einsum("za,zak->ak", W, neb_coeffs_all)
        neb_per_age = neb_weighted @ self._neb_svd_basis
        neb_attn = jnp.sum(neb_per_age * attn_age, axis=0)

        attenuated = (stellar_attn_final + neb_attn) * diffuse_curve

        # --- Dust emission ---
        dust_emi_spectrum, _, _ = self.dust_emi.compute_dust_emission(
            spec_attn=attenuated, spec_dustfree=spectrum_dust_free,
            spec_lambda=self.wave, diffuse_curve=diffuse_curve,
            duste_qpah=theta["duste_qpah"],
            duste_umin=theta["duste_umin"],
            duste_gamma=theta["duste_gamma"],
        )
        return dust_emi_spectrum

    # ===================================================================
    # Display / repr
    # ===================================================================

    def __repr__(self):
        base = super().__repr__()
        if self.use_svd:
            svd_info = (
                f"\nSVD compression : ON"
                f"\n  Stellar k        : {self._svd_k}"
                f"\n  Stellar variance : "
                f"{float(jnp.sum(self._svd_S**2) / jnp.sum(self._svd_S_full**2))*100:.4f}%"
            )
            if self._has_neb_svd:
                svd_info += (
                    f"\n  Nebular k        : {self._neb_svd_k}"
                    f"\n  Nebular variance : "
                    f"{float(jnp.sum(self._neb_svd_S**2) / jnp.sum(self._neb_svd_S_full**2))*100:.4f}%"
                )
        else:
            svd_info = "\nSVD compression : OFF"
        return base + svd_info
