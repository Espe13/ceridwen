import os
import time
import pathlib

import pytest

# This module is an FSPS integration test: it builds a reference spectrum with
# FSPS, so it skips entirely where FSPS is not installed (e.g. CI).
fsps = pytest.importorskip("fsps")

import numpy as np
import jax
import jax.numpy as jnp
import matplotlib
matplotlib.use("Agg")  # headless
import matplotlib.pyplot as plt
import pprint

# Optional plotting style; ignore if scienceplots is not installed.
try:
    import scienceplots  # noqa: F401
    plt.style.use(["science", "nature", "no-latex"])
except Exception:
    pass

# ── Ceridwen imports ────────────────────────────────────────────────────────
from ceridwen.ssps.ssp_data import SSPData
from ceridwen.csp.csp import CSPBasis, fnu2flam
from ceridwen.observation.observation import Photometry, Spectrum, Lines
from ceridwen.model.model import SedModel

from _gridfixture import require_test_grid

# ── Output folder ─────────────────────────────────────────────────────────────
FIG_DIR = pathlib.Path(__file__).parent / "predict_figures"
FIG_DIR.mkdir(exist_ok=True)


# ── Paths ─────────────────────────────────────────────────────────────────────
SSP_FILE = str(require_test_grid())
SPS_HOME = os.environ.get("SPS_HOME")

# ── Dust / nebular parameter values ──────────────────────────────────────────
DIFFUSE_TAU   = 2.0
DIFFUSE_INDEX = -0.7
YOUNG_TAU     = 2.0
YOUNG_INDEX   = -1.0
GAS_LOGZ      = 0.0
GAS_LOGU      = -2.0

# FSPS metallicity index (1-based); metallicity value derived after sp is built
ZMET_IDX = 1

# SFH grid
T_UNIV  = 13.8   # Gyr
N_TIME  = 10
t_grid   = jnp.linspace(1e-2, T_UNIV, N_TIME)   # cosmic time [Gyr]
lookback = jnp.linspace(0.0, T_UNIV, N_TIME)      # NEW convention

def gaussian_burst(tau, center, width, amp=1.0):
    return amp * jnp.exp(-0.5 * ((tau - center) / width) ** 2)

sfr_bimodal = (gaussian_burst(lookback, 0.05, 0.03, 1.0) +
               gaussian_burst(lookback, 11.0, 0.8,  0.7))

# ── Load SSP data ─────────────────────────────────────────────────────────────
ssp_data = SSPData.load(SSP_FILE)




# ── CSP shared setup ──────────────────────────────────────────────────────────
DUST_BIN_PARAMS = {
    'bin_edges': [(-jnp.inf, -1.97)],   # young bin: log10(age/Gyr) < -1.97
    'laws':      ['powerlaw'],
}

BASE_THETA = {
    'lookback_time': lookback,
    'sfh':           sfr_bimodal,
    'Z':             jnp.array([-4]),
}

csp = CSPBasis(
        ssp_data,
        theta        = BASE_THETA.copy(),
        tuniv             = T_UNIV,
        tiny_logt         = -70,
        zh_const          = True,
        add_dust          = True,
        add_diffuse_dust  = True,
        add_dust_emission = True,
        add_neb           = True,
        init_neb_params   = {'isoc_type': 'mist', 'cloudy_dust': False},
        init_dust_params  = DUST_BIN_PARAMS,
        diffuse_law       = 'kriek_conroy',
        sps_home          = SPS_HOME,
        verbose           = False,
    )

spectrum = csp.get_spectrum(csp.theta_init)

# ── Mock Observation ───────────────────────────────────────────────────

#PHOTOMETRY

filter_names = [
    'sdss_u0', 'sdss_g0', 'sdss_r0', 'sdss_i0', 'sdss_z0'
]
# (flux/uncertainty set to ones; overwritten below after computing model maggies)
dummy_phot = Photometry(filters=filter_names, name='sdss_2mass')

# True model maggies from the fiducial spectrum add Gaussian Noise
true_maggies = dummy_phot.get_maggies(csp.wave, spectrum)

# Add 5 % Gaussian noise (realistic for broadband photometry)
rng        = np.random.default_rng(seed=42)
noise_frac = 0.05
phot_unc   = jnp.array(noise_frac * np.abs(np.array(true_maggies)))
phot_flux  = true_maggies + jnp.array(rng.normal(0, np.array(phot_unc)))

phot = Photometry(
    filters     = filter_names,
    flux        = phot_flux,
    uncertainty = phot_unc,
    name        = 'sdss_2mass',
)



# Lines
from pathlib import Path

fname = Path("/Users/amanda/Prospector/fsps/data/emlines_info.dat")

waves = []
names = []

with open(fname, "r") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        w, name = line.split(",", 1)
        waves.append(float(w))
        names.append(name.strip())

for i, (w, n) in enumerate(zip(waves, names)):
    if n in ["[O II] 3726", "Ba-beta 4861", "[O III] 4959", "[O III] 5007", "Ba-alpha 6563"]:
        print(i, w, n)

target_map = {
    "[OII]3727": "[O II] 3726",
    "Hbeta": "Ba-beta 4861",
    "[OIII]4959": "[O III] 4959",
    "[OIII]5007": "[O III] 5007",
    "Halpha": "Ba-alpha 6563",
}

LINE_NAMES = ['[OII]3727', 'Hbeta', '[OIII]4959', '[OIII]5007', 'Halpha']
LINE_WAVES = []
LINE_INDS = []

for wanted in LINE_NAMES:
    fsps_name = target_map[wanted]
    idx = names.index(fsps_name)
    LINE_INDS.append(idx)
    LINE_WAVES.append(waves[idx])

print("LINE_NAMES =", LINE_NAMES)
print("LINE_WAVES =", LINE_WAVES)
print("LINE_INDS  =", LINE_INDS)
# Build the Lines object.  We must call setup_for_model(csp.wave) before
# calling predict(), so that the Gaussian weight matrix _W is precomputed.
# SedModel does this automatically; here we do it manually for the direct test.

# First create with placeholder flux / uncertainty (overwritten below).
lines_obs = Lines(
    line_ind   = LINE_INDS,
    line_names = LINE_NAMES,
    wavelength = LINE_WAVES,
    flux       = np.ones(len(LINE_NAMES)),
    uncertainty= np.ones(len(LINE_NAMES)),
    name       = 'optical_lines',
)
# Precompute weight matrix on the model wavelength grid.
lines_obs.setup_for_model(csp.wave, sigma_v=200.0)

# True 'line fluxes' from the model (continuum integral under Gaussian aperture)
true_line_fluxes = lines_obs.predict(spectrum, csp.wave)
line_unc         = jnp.array(0.10 * np.abs(np.array(true_line_fluxes)) + 1e-5)
line_flux_obs    = true_line_fluxes + jnp.array(rng.normal(0, np.array(line_unc)))

# Now replace the placeholder data with the simulated observations.
lines_obs_final = Lines(
    line_ind   = LINE_INDS,
    line_names = LINE_NAMES,
    wavelength = LINE_WAVES,
    flux       = line_flux_obs,
    uncertainty= line_unc,
    name       = 'optical_lines',
)
lines_obs_final.setup_for_model(csp.wave, sigma_v=200.0)
lines_obs = lines_obs_final   # use this from here on

print(lines_obs)
print(f'\n  True line fluxes   : {np.array(true_line_fluxes)}')
print(f'  Mock obs fluxes    : {np.array(lines_obs.flux)}')




#SPECTRUM

n_pix     = 300
wave_spec = jnp.array(np.geomspace(4000., 7000., n_pix))   # Å

# Build Spectrum observation and precompute the interpolation matrix.
# setup_for_model creates _H ∈ R^{n_pix × n_wave} so that predict = _H @ spectrum.
# Must be called once before JIT-compiling any function containing predict().

# True model flux via direct interpolation (for generating mock data)
true_spec = jnp.interp(wave_spec, csp.wave, spectrum)

spec_unc  = jnp.array(0.02 * np.abs(np.array(true_spec)) + 1e-5 * float(jnp.max(true_spec)))
spec_flux = true_spec + jnp.array(rng.normal(0, np.array(spec_unc)))

spec_obs = Spectrum(
    wavelength  = wave_spec,
    flux        = spec_flux,
    uncertainty = spec_unc,
    resolution  = 300.0,
    name        = 'optical_spec',
    smoothtype  = 'vel',

)
# Precompute the dense interpolation matrix.
spec_obs.setup_for_model(csp.wave)

print(spec_obs)
print(f'\n  _H matrix shape : {spec_obs._H.shape}  '
      f'(n_pix={n_pix} × n_wave={len(csp.wave)})')
print(f'  _H dtype        : {spec_obs._H.dtype}')





print()
print()
print('OBSERVATION COMBINED')
print()
print()


observations = [phot, spec_obs, lines_obs]

predictions = csp.predict(csp.theta_init, observations)

pprint.pprint(predictions)


# ── Comparison plot: spectrum + photometry combined, lines below ──────────────
cmap = plt.get_cmap("twilight_shifted")
cpal = cmap(jnp.linspace(0.15, 0.85, 20))

obs_wave  = np.array(spec_obs.wavelength)
obs_flux  = np.array(spec_obs.flux)
obs_sunc  = np.array(spec_obs.uncertainty)
pred_spec = np.array(predictions['optical_spec'])

weff     = np.array(phot.wavelength)
obs_mag  = np.array(phot.flux)
obs_unc  = np.array(phot.uncertainty)
pred_mag = np.array(predictions['sdss_2mass'])

obs_lflux = np.array(lines_obs.flux)
obs_lunc  = np.array(lines_obs.uncertainty)
pred_line = np.array(predictions['optical_lines'])

# Convert photometric maggies → F_nu (Lsun/Hz) so they sit on the spectrum.
# Scale factor: model F_nu at filter effective wavelength / predicted maggie.
model_fnu_at_weff = np.interp(weff, np.array(csp.wave), np.array(spectrum))
mag2fnu           = model_fnu_at_weff / np.array(pred_mag)
phot_fnu_obs      = np.array(obs_mag)  * mag2fnu
phot_fnu_unc      = np.array(obs_unc)  * mag2fnu
phot_fnu_pred     = np.array(pred_mag) * mag2fnu    # == model_fnu_at_weff

full_wave = np.array(csp.wave)
full_spec = np.array(spectrum)

fig, (ax_sed, ax_lines) = plt.subplots(
    2, 1, figsize=(8, 7), gridspec_kw={'height_ratios': [3, 1]},
)

# ── Top panel: full SED with spectrum and photometry overlaid ────────────────
# Full model spectrum as faint background
ax_sed.plot(full_wave, full_spec, color='0.75', lw=0.5, zorder=0,
            label='Full model spectrum')

# Observed spectral window: mock data ± 1σ
ax_sed.fill_between(obs_wave, obs_flux - obs_sunc, obs_flux + obs_sunc,
                    color=cpal[5], alpha=0.25, zorder=1)
ax_sed.plot(obs_wave, obs_flux, color=cpal[5], lw=3, alpha=0.8,
            label='Mock spectrum $\\pm 1\\sigma$', zorder=2)

# Predicted spectrum in the observed window
ax_sed.plot(obs_wave, pred_spec, color=cpal[19], lw=1,
            label='Predicted spectrum', zorder=3)

# Photometry: observed (circles with errorbars) and predicted (squares)
ax_sed.errorbar(weff, phot_fnu_obs, yerr=phot_fnu_unc, fmt='o', ms=7,
                color=cpal[5], capsize=4, lw=1.2, zorder=15,
                label='Mock photometry')
ax_sed.scatter(weff, phot_fnu_pred, marker='s', s=70, color=cpal[19],
               edgecolors='k', linewidths=0.6, zorder=6,
               label='Predicted photometry')

# Filter transmission curves (scaled to sit at the bottom of the plot)
ax_filt = ax_sed.twinx()
for i, f in enumerate(phot.filters):
    fw = np.array(f.wavelength)
    ft = np.array(f.transmission)
    ft_norm = ft / ft.max()                       # normalise peak to 1
    ax_filt.fill_between(fw, 0, ft_norm, color=cpal[5 + 3 * i], alpha=0.15)
    ax_filt.plot(fw, ft_norm, color=cpal[5 + 3 * i], lw=0.7, alpha=0.5)
    ax_filt.text(weff[i], ft[ft.argmax()] / ft.max() + 0.03,
                 filter_names[i].replace('_', ' '),
                 ha='center', fontsize=5, alpha=0.6, fontstyle='italic')
ax_filt.set_ylim(0, 5)                            # push curves to lower ~20% of panel
ax_filt.set_yticks([])
ax_filt.set_ylabel('')

# Shade the spectral observation window
ax_sed.axvspan(obs_wave.min(), obs_wave.max(), color=cpal[19], alpha=0.04, zorder=-1)

ax_sed.set_xlim(2e3, 3e4)
ax_sed.set_ylim(1e-8, 1e-4)
ax_sed.set_xlabel('Wavelength (\\AA)')
ax_sed.set_ylabel('$F_\\nu$ (Lsun/Hz)')
ax_sed.set_yscale('log')
ax_sed.set_xscale('log')
ax_sed.set_title('SED: model spectrum + photometry + spectroscopic window')
ax_sed.legend(fontsize=7, loc='lower left', ncol=2)


# ── Bottom panel: emission lines ─────────────────────────────────────────────
x_pos = np.arange(len(LINE_NAMES))
bar_w = 0.3
ax_lines.bar(x_pos - bar_w / 2, obs_lflux, bar_w, yerr=obs_lunc,
             color=cpal[5], capsize=3, label='Mock observation', alpha=0.8, zorder =5)
ax_lines.bar(x_pos + bar_w / 2, pred_line, bar_w,
             color=cpal[19], label='Predicted', alpha=0.8)
ax_lines.set_xticks(x_pos)
ax_lines.set_xticklabels(LINE_NAMES, fontsize=7, rotation=30, ha='right')
ax_lines.set_ylabel('Line flux')
ax_lines.set_title('Emission lines')
ax_lines.legend(fontsize=8)

plt.tight_layout()
plt.savefig(FIG_DIR / "mock_vs_predicted.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"\nComparison figure saved to {FIG_DIR / 'mock_vs_predicted.pdf'}")


# ── Residual summary ─────────────────────────────────────────────────────────
print("\nResiduals (predicted - mock obs) / uncertainty:")
print(f"  Photometry : {np.array((pred_mag - obs_mag) / obs_unc)}")
print(f"  Lines      : {np.array((pred_line - obs_lflux) / obs_lunc)}")
spec_resid = (pred_spec - obs_flux) / obs_sunc
print(f"  Spectrum   : mean {spec_resid.mean():.3f}  std {spec_resid.std():.3f}")


# ===========================================================================
# JIT test: compile csp.predict and run 1000 different thetas
# ===========================================================================
import time

N_JIT = 1000
rng_jit = np.random.default_rng(123)

print("\n" + "=" * 60)
print("  JIT benchmark: csp.predict with 1000 random thetas")
print("=" * 60)

# JIT-compile predict with the observation list baked in as a static closure
predict_jit = jax.jit(lambda theta: csp.predict(theta, observations))

# Generate random thetas (vary dust, neb, and duste params)
base = csp.theta_init.copy()
rand_thetas = []
for _ in range(N_JIT):
    t = base.copy()
    t['diffuse_tau_kc']     = float(rng_jit.uniform(0.1,  4.0))
    t['diffuse_dust_index'] = float(rng_jit.uniform(-1.5, 0.5))
    t['tau_pow']            = float(rng_jit.uniform(0.0,  3.0))
    t['alpha']              = float(rng_jit.uniform(-2.0, 0.0))
    t['gas_logz']           = jnp.array([float(rng_jit.uniform(-1.0, 0.5))])
    t['gas_logu']           = jnp.array([float(rng_jit.uniform(-4.0, -1.0))])
    t['duste_qpah']         = float(rng_jit.uniform(0.5,  4.5))
    t['duste_umin']         = float(rng_jit.uniform(0.1,  15.0))
    t['duste_gamma']        = float(rng_jit.uniform(0.0,  0.15))
    rand_thetas.append(t)

# Warm-up (compilation)
print("  Compiling ...", end=" ", flush=True)
t0_compile = time.perf_counter()
warmup = predict_jit(rand_thetas[0])
# block on every output array to ensure compilation is done
for v in warmup.values():
    v.block_until_ready()
compile_ms = (time.perf_counter() - t0_compile) * 1e3
print(f"done ({compile_ms:.0f} ms)")

# Collect all predictions and per-call timing
all_phot  = np.empty((N_JIT, len(filter_names)))
all_spec  = np.empty((N_JIT, len(obs_wave)))
all_lines = np.empty((N_JIT, len(LINE_NAMES)))
times_ms  = np.empty(N_JIT)

print(f"  Running {N_JIT} calls ...", end=" ", flush=True)
for i, theta in enumerate(rand_thetas):
    t0 = time.perf_counter()
    preds = predict_jit(theta)
    # block on one output to synchronise
    preds['sdss_2mass'].block_until_ready()
    times_ms[i] = (time.perf_counter() - t0) * 1e3

    all_phot[i]  = np.array(preds['sdss_2mass'])
    all_spec[i]  = np.array(preds['optical_spec'])
    all_lines[i] = np.array(preds['optical_lines'])

print(f"done")
print(f"  Mean {times_ms[1:].mean():.3f} ms  std {times_ms[1:].std():.3f} ms  "
      f"(excluding first call)")

# ── Figure 1: how predictions evolve across 1000 random thetas ───────────────
fig, axes = plt.subplots(3, 1, figsize=(8, 9))

# Photometry evolution
ax = axes[0]
for j, fn in enumerate(filter_names):
    ax.plot(all_phot[:, j], lw=0.4, alpha=0.8, label=fn.replace('_', ' '))
    ax.axhline(obs_mag[j], color='k', ls='--', lw=0.5, alpha=0.4)
ax.set_xlabel('Theta index')
ax.set_ylabel('Maggies')
ax.set_title('Photometry predictions across 1000 random thetas')
ax.legend(fontsize=6, ncol=len(filter_names), loc='upper right')

# Spectrum evolution (show every 50th as a line, rest as faint background)
ax = axes[1]
for i in range(0, N_JIT, 50):
    ax.plot(obs_wave, all_spec[i], lw=0.5, alpha=0.4, color=cpal[19])
ax.fill_between(obs_wave, obs_flux - obs_sunc, obs_flux + obs_sunc,
                color=cpal[5], alpha=0.3, zorder=10)
ax.plot(obs_wave, obs_flux, color=cpal[5], lw=1.5, zorder=11,
        label='Mock observation')
ax.plot([], [], color=cpal[19], lw=0.8, label='Predicted (every 50th)')
ax.set_xlabel('Wavelength (\\AA)')
ax.set_ylabel('$F_\\nu$ (Lsun/Hz)')
ax.set_title(f'Spectrum predictions ({N_JIT} thetas, every 50th shown)')
ax.legend(fontsize=7)

# Line flux evolution
ax = axes[2]
for j, ln in enumerate(LINE_NAMES):
    ax.plot(all_lines[:, j], lw=0.4, alpha=0.8, label=ln)
    ax.axhline(obs_lflux[j], color='k', ls='--', lw=0.5, alpha=0.4)
ax.set_xlabel('Theta index')
ax.set_ylabel('Line flux')
ax.set_title('Emission line predictions across 1000 random thetas')
ax.legend(fontsize=6, ncol=len(LINE_NAMES), loc='upper right')

plt.tight_layout()
plt.savefig(FIG_DIR / "predict_evolution.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"  Evolution figure saved to {FIG_DIR / 'predict_evolution.pdf'}")

# ── Figure 2: timing per call ────────────────────────────────────────────────
fig, (ax_hist, ax_trace) = plt.subplots(1, 2, figsize=(9, 3.5))

# Histogram of call times (skip first call which may include residual overhead)
ax_hist.hist(times_ms[1:], bins=50, color=cpal[19], edgecolor='k', lw=0.3)
ax_hist.axvline(times_ms[1:].mean(), color='k', ls='--', lw=1,
                label=f'mean = {times_ms[1:].mean():.2f} ms')
ax_hist.set_xlabel('Time per predict() call (ms)')
ax_hist.set_ylabel('Count')
ax_hist.set_title('JIT-compiled predict() latency')
ax_hist.legend(fontsize=8)

# Time trace (to spot any retracing spikes)
ax_trace.plot(times_ms, lw=0.5, color=cpal[19])
ax_trace.axhline(times_ms[1:].mean(), color='k', ls='--', lw=0.8, alpha=0.6)
ax_trace.set_xlabel('Call index')
ax_trace.set_ylabel('Time (ms)')
ax_trace.set_title('Per-call timing trace')

plt.tight_layout()
plt.savefig(FIG_DIR / "predict_timing.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"  Timing figure saved to {FIG_DIR / 'predict_timing.pdf'}")
print(f"\n  JIT predict() is working: {N_JIT} calls completed successfully.")


# ===========================================================================
# Instrumental smoothing demonstration
# ===========================================================================
# Construct several Spectrum objects over the same observed pixel grid,
# each with a different smoothing configuration, and compare the predictions.
#
# The raw model spectrum (spectrum / csp.wave) is fixed; what changes is how
# each Spectrum.predict() convolves it before interpolating to observed pixels.
# ===========================================================================

print("\n" + "=" * 60)
print("  Instrumental smoothing demonstration")
print("=" * 60)

# ── Shared observed wavelength grid ───────────────────────────────────────────
n_pix_sm  = 600
wave_sm   = jnp.array(np.geomspace(3700., 7200., n_pix_sm))   # Å, fine grid

# Dummy flux / uncertainty — required to satisfy Observation.rectify() which
# resets self._wavelength = None when flux is absent.  The actual values do
# not matter here because we only call predict(), never chi_sq().
_dummy_flux = jnp.ones(n_pix_sm)
_dummy_unc  = jnp.ones(n_pix_sm)

# Reference spectrum: no smoothing — pure linear interpolation
spec_nsmooth = Spectrum(
    wavelength  = wave_sm,
    flux        = _dummy_flux,
    uncertainty = _dummy_unc,
    name        = 'no_smoothing',
    smoothtype  = None,
)
spec_nsmooth.setup_for_model(csp.wave)

# Velocity smoothing — σ_v = 50 km/s  (narrow, e.g., high-res spectrograph)
spec_vel50 = Spectrum(
    wavelength  = wave_sm,
    flux        = _dummy_flux,
    uncertainty = _dummy_unc,
    name        = 'vel_50kms',
    resolution  = 50.0,
    smoothtype  = 'vel',
)
spec_vel50.setup_for_model(csp.wave)

# Velocity smoothing — σ_v = 150 km/s  (moderate, e.g., SDSS-like)
spec_vel150 = Spectrum(
    wavelength  = wave_sm,
    flux        = _dummy_flux,
    uncertainty = _dummy_unc,
    name        = 'vel_150kms',
    resolution  = 150.0,
    smoothtype  = 'vel',
)
spec_vel150.setup_for_model(csp.wave)

# Velocity smoothing — σ_v = 350 km/s  (broad, e.g., low-res or high-z)
spec_vel350 = Spectrum(
    wavelength  = wave_sm,
    flux        = _dummy_flux,
    uncertainty = _dummy_unc,
    name        = 'vel_350kms',
    resolution  = 350.0,
    smoothtype  = 'vel',
)
spec_vel350.setup_for_model(csp.wave)

# Wavelength smoothing — σ_λ = 3 Å  (fixed-wavelength, e.g., Gaussian LSF)
spec_lam3 = Spectrum(
    wavelength  = wave_sm,
    flux        = _dummy_flux,
    uncertainty = _dummy_unc,
    name        = 'lambda_3A',
    resolution  = 3.0,
    smoothtype  = 'lambda',
)
spec_lam3.setup_for_model(csp.wave)

# Wavelength smoothing — σ_λ = 10 Å  (broader fixed-wavelength)
spec_lam10 = Spectrum(
    wavelength  = wave_sm,
    flux        = _dummy_flux,
    uncertainty = _dummy_unc,
    name        = 'lambda_10A',
    resolution  = 10.0,
    smoothtype  = 'lambda',
)
spec_lam10.setup_for_model(csp.wave)

# LSF smoothing — wavelength-dependent σ(λ): varies linearly from 2 Å at
# blue end to 8 Å at red end, mimicking a typical grism detector.
sigma_lsf_obs = np.linspace(2.0, 8.0, n_pix_sm)
spec_lsf = Spectrum(
    wavelength  = wave_sm,
    flux        = _dummy_flux,
    uncertainty = _dummy_unc,
    name        = 'lsf_2to8A',
    resolution  = sigma_lsf_obs,
    smoothtype  = 'lsf',
)
spec_lsf.setup_for_model(csp.wave)

# ── Run predictions with the fiducial theta ───────────────────────────────────
pred_nsmooth = spec_nsmooth.predict(spectrum, csp.wave)
pred_vel50   = spec_vel50.predict(spectrum, csp.wave)
pred_vel150  = spec_vel150.predict(spectrum, csp.wave)
pred_vel350  = spec_vel350.predict(spectrum, csp.wave)
pred_lam3    = spec_lam3.predict(spectrum, csp.wave)
pred_lam10   = spec_lam10.predict(spectrum, csp.wave)
pred_lsf     = spec_lsf.predict(spectrum, csp.wave)

# Convert to numpy for plotting
wobs = np.array(wave_sm)
p_ns  = np.array(pred_nsmooth)
p_v50 = np.array(pred_vel50)
p_v150= np.array(pred_vel150)
p_v350= np.array(pred_vel350)
p_l3  = np.array(pred_lam3)
p_l10 = np.array(pred_lam10)
p_lsf = np.array(pred_lsf)

print("  All smoothed predictions computed.")
print(f"  Output shape: {pred_nsmooth.shape}   (n_pix = {n_pix_sm})")

# ── Figure: smoothing comparison ──────────────────────────────────────────────
# Two panels:
#   Top   — full spectral window showing all smoothing modes
#   Bottom— zoom onto Hα + [N II] region to show line broadening clearly

fig, axes = plt.subplots(
    2, 1, figsize=(9, 8),
    gridspec_kw={'height_ratios': [2, 1.2]},
)

cmap2 = plt.get_cmap("viridis")
nlines = 6
cp = cmap2(np.linspace(0.08, 0.88, nlines))

ax = axes[0]
ax.plot(wobs, p_ns,   color='0.50', lw=0.7, zorder=2,
        label='No smoothing (reference)', alpha=0.7)
ax.plot(wobs, p_v50,  color=cp[0],  lw=1.1, label=r'vel  $\sigma_v = 50$ km s$^{-1}$')
ax.plot(wobs, p_v150, color=cp[1],  lw=1.1, label=r'vel  $\sigma_v = 150$ km s$^{-1}$')
ax.plot(wobs, p_v350, color=cp[2],  lw=1.3, label=r'vel  $\sigma_v = 350$ km s$^{-1}$')
ax.plot(wobs, p_l3,   color=cp[3],  lw=1.1, ls='--',
        label=r'$\lambda$  $\sigma_\lambda = 3$ \AA')
ax.plot(wobs, p_l10,  color=cp[4],  lw=1.3, ls='--',
        label=r'$\lambda$  $\sigma_\lambda = 10$ \AA')
ax.plot(wobs, p_lsf,  color=cp[5],  lw=1.3, ls=':',
        label=r'LSF  $\sigma(\lambda) = 2\,{\to}\,8$ \AA')

ax.set_xlim(wobs.min(), wobs.max())
ax.set_ylim(bottom=0)
ax.set_xlabel(r'Wavelength (\AA)')
ax.set_ylabel(r'$F_\nu$ (L$_\odot$ Hz$^{-1}$ M$_\odot^{-1}$)')
ax.set_title('Instrumental smoothing modes: full spectral window')
ax.legend(fontsize=7, ncol=2, loc='upper right')

# ── Zoom panel: Hα region (6450–6620 Å) ──────────────────────────────────────
ha_lo, ha_hi = 6440., 6630.
mask_ha = (wobs >= ha_lo) & (wobs <= ha_hi)

ax = axes[1]
ax.plot(wobs[mask_ha], p_ns[mask_ha],   color='0.50', lw=0.9, alpha=0.7,
        label='No smoothing')
ax.plot(wobs[mask_ha], p_v50[mask_ha],  color=cp[0],  lw=1.1,
        label=r'vel 50 km s$^{-1}$')
ax.plot(wobs[mask_ha], p_v150[mask_ha], color=cp[1],  lw=1.1,
        label=r'vel 150 km s$^{-1}$')
ax.plot(wobs[mask_ha], p_v350[mask_ha], color=cp[2],  lw=1.3,
        label=r'vel 350 km s$^{-1}$')
ax.plot(wobs[mask_ha], p_l3[mask_ha],   color=cp[3],  lw=1.1, ls='--',
        label=r'$\lambda$ 3 \AA')
ax.plot(wobs[mask_ha], p_l10[mask_ha],  color=cp[4],  lw=1.3, ls='--',
        label=r'$\lambda$ 10 \AA')
ax.plot(wobs[mask_ha], p_lsf[mask_ha],  color=cp[5],  lw=1.3, ls=':',
        label=r'LSF $2\to8$ \AA')

# Mark Hα rest wavelength
ax.axvline(6562.8, color='k', lw=0.7, ls=':', alpha=0.5)
ax.text(6562.8 + 4, ax.get_ylim()[1] * 0.02 if ax.get_ylim()[1] > 0 else 1e-7,
        r'H$\alpha$', fontsize=7, color='k', alpha=0.6, va='bottom')

ax.set_xlim(ha_lo, ha_hi)
ax.set_xlabel(r'Wavelength (\AA)')
ax.set_ylabel(r'$F_\nu$ (L$_\odot$ Hz$^{-1}$ M$_\odot^{-1}$)')
ax.set_title(r'Zoom: H$\alpha$ region — line broadening comparison')
ax.legend(fontsize=7, ncol=3, loc='upper left')

plt.tight_layout()
fig_path = FIG_DIR / "smoothing_comparison.pdf"
plt.savefig(fig_path, dpi=150, bbox_inches='tight')
plt.close()
print(f"  Smoothing comparison figure saved to {fig_path}")

# ── JIT test: verify all predict_fn closures are JIT-compilable ───────────────
print("\n  Verifying JIT-compilability of all smoothing modes ...")
predict_fns = {
    'no_smoothing' : jax.jit(lambda s: spec_nsmooth.predict(s, csp.wave)),
    'vel_50'       : jax.jit(lambda s: spec_vel50.predict(s, csp.wave)),
    'vel_150'      : jax.jit(lambda s: spec_vel150.predict(s, csp.wave)),
    'vel_350'      : jax.jit(lambda s: spec_vel350.predict(s, csp.wave)),
    'lambda_3'     : jax.jit(lambda s: spec_lam3.predict(s, csp.wave)),
    'lambda_10'    : jax.jit(lambda s: spec_lam10.predict(s, csp.wave)),
    'lsf'          : jax.jit(lambda s: spec_lsf.predict(s, csp.wave)),
}

for name, fn in predict_fns.items():
    t0   = time.perf_counter()
    out  = fn(spectrum)
    out.block_until_ready()
    t_ms = (time.perf_counter() - t0) * 1e3
    print(f"    {name:<18s}  shape={out.shape}  compile+run={t_ms:.1f} ms")

print("\n  All smoothing modes JIT-compiled successfully.")


# ===========================================================================
# Prospector-parity feature demonstrations
# ===========================================================================
# Six new Spectrum / Lines capabilities are tested here, one section per
# feature.  Each section builds a minimal mock observation, exercises the
# new code path, and produces a figure saved to FIG_DIR.
# ===========================================================================

from ceridwen.observation.observation import GaussianProcess

print("\n" + "=" * 60)
print("  Prospector-parity feature demonstrations")
print("=" * 60)

# ── Shared spectral grid for all demonstrations ───────────────────────────────
n_demo    = 400
wave_demo = jnp.array(np.geomspace(3700., 7200., n_demo))

# Predict the model on this grid (no smoothing — just interpolation)
_spec_demo_obj = Spectrum(
    wavelength  = wave_demo,
    flux        = jnp.ones(n_demo),
    uncertainty = jnp.ones(n_demo),
    name        = '_demo_base',
    smoothtype  = None,
)
_spec_demo_obj.setup_for_model(csp.wave)
model_demo = _spec_demo_obj.predict(spectrum, csp.wave)   # true model on demo grid

rng_demo = np.random.default_rng(seed=99)

# ===========================================================================
# Feature 1: Sky spectrum subtraction
# ===========================================================================
print("\n  [1] Sky spectrum subtraction ...")

# Simulate an observed sky background: smooth, low-amplitude continuum with
# a few bright sky emission lines (e.g. O I 5577, Na D 5893, OH bands)
sky_continuum = 0.08 * float(jnp.median(model_demo)) * np.ones(n_demo)
sky_lines_wave = np.array([5577., 5893., 6300., 6864.])
sky_lines_amp  = np.array([0.40,  0.25,  0.20,  0.15]) * float(jnp.median(model_demo))
sky_spectrum   = sky_continuum.copy()
for wl, amp in zip(sky_lines_wave, sky_lines_amp):
    sky_spectrum += amp * np.exp(-0.5 * ((np.array(wave_demo) - wl) / 5.0) ** 2)
sky_jnp = jnp.array(sky_spectrum)

# Observed flux = model + sky + noise
obs_unc_sky  = jnp.array(0.03 * np.abs(np.array(model_demo)) + 1e-6)
obs_flux_sky = model_demo + sky_jnp + jnp.array(
    rng_demo.normal(0, np.array(obs_unc_sky))
)

spec_with_sky = Spectrum(
    wavelength  = wave_demo,
    flux        = obs_flux_sky,
    uncertainty = obs_unc_sky,
    name        = 'sky_demo',
    smoothtype  = 'vel',
    resolution  = 120.0,
    sky         = sky_jnp,
)
spec_with_sky.setup_for_model(csp.wave)
pred_sky_demo = spec_with_sky.predict(spectrum, csp.wave)

chi2_without_sky_sub = float(jnp.sum(((obs_flux_sky - pred_sky_demo) / obs_unc_sky) ** 2))
chi2_with_sky_sub    = spec_with_sky.chi_sq(pred_sky_demo)

print(f"    chi2 without sky subtraction : {chi2_without_sky_sub:.1f}")
print(f"    chi2 with    sky subtraction : {chi2_with_sky_sub:.1f}")

# Pre-compute residuals for figure
wdemo_np  = np.array(wave_demo)
resid_raw = (np.array(obs_flux_sky) - np.array(pred_sky_demo)) / np.array(obs_unc_sky)
resid_sky = np.array(spec_with_sky.residuals(pred_sky_demo))

# Figure — 3 panels, distinct colours
# Panel 1: raw (sky-contaminated) observed flux vs model
# Panel 2: sky background spectrum with line labels
# Panel 3: residuals before/after sky subtraction
C_OBS   = '#1a4e8a'   # dark blue  — raw observed flux (sky-contaminated)
C_SUB   = '#2ca02c'   # green      — sky-subtracted data
C_MODEL = '#555555'   # dark grey  — model prediction
C_SKY   = '#d6a820'   # amber      — sky background

fig, axes = plt.subplots(3, 1, figsize=(9, 8),
                          gridspec_kw={'height_ratios': [2, 1.2, 1]})

# ── Panel 1: raw flux and sky-subtracted flux vs model ───────────────
ax = axes[0]
ax.plot(wdemo_np, np.array(obs_flux_sky),
        color=C_OBS, lw=1.1, alpha=0.9, label='Observed (object + sky)')
ax.plot(wdemo_np, np.array(obs_flux_sky) - sky_spectrum,
        color=C_SUB, lw=1.3, label='Sky-subtracted data')
ax.plot(wdemo_np, np.array(pred_sky_demo),
        color=C_MODEL, lw=0.9, ls='--', zorder=5, label='Model prediction')
ax.set_ylabel(r'$F_\nu$ (L$_\odot$ Hz$^{-1}$ M$_\odot^{-1}$)')
ax.set_title('Feature 1: Sky spectrum subtraction', fontsize=10)
ax.legend(fontsize=8, loc='upper right')
ax.set_xlim(wdemo_np.min(), wdemo_np.max())

# ── Panel 2: sky background in isolation, with line labels ───────────
ax = axes[1]
ax.fill_between(wdemo_np, 0, sky_spectrum, color=C_SKY, alpha=0.35)
ax.plot(wdemo_np, sky_spectrum, color=C_SKY, lw=1.2, label='Sky background')
sky_label_map = {5577.: r'O\,{\sc i} 5577', 5893.: r'Na\,D 5893',
                 6300.: r'O\,{\sc i} 6300', 6864.: r'OH 6864'}
for wl, lbl in sky_label_map.items():
    yp = float(np.interp(wl, wdemo_np, sky_spectrum))
    ax.axvline(wl, color=C_SKY, lw=0.7, ls=':', alpha=0.7)
    ax.text(wl + 12, yp * 0.55, lbl, fontsize=6.5, color='#8a6010',
            rotation=0, ha='left', va='center')
ax.set_ylabel(r'$F_{\nu,\,\rm sky}$')
ax.set_xlim(wdemo_np.min(), wdemo_np.max())
ax.set_ylim(bottom=0)
ax.legend(fontsize=8, loc='upper right')

# ── Panel 3: normalised residuals before / after sky subtraction ─────
ax = axes[2]
ax.fill_between(wdemo_np, -1, 1, color='0.88', label=r'$\pm 1\sigma$')
ax.axhline(0, color='k', lw=0.6, ls=':')
ax.plot(wdemo_np, resid_raw, color=C_OBS, lw=0.9, alpha=0.85,
        label=r'$(d_{\rm raw} - m)\,/\,\sigma$')
ax.plot(wdemo_np, resid_sky, color=C_SUB, lw=1.0,
        label=r'$(d_{\rm sky\text{-}sub} - m)\,/\,\sigma$')
ax.set_xlabel(r'Wavelength (\AA)')
ax.set_ylabel(r'Residual / $\sigma$')
ax.set_ylim(-12, 12)
ax.set_xlim(wdemo_np.min(), wdemo_np.max())
ax.legend(fontsize=7, ncol=3, loc='upper right')

plt.tight_layout()
plt.savefig(FIG_DIR / "feature_sky_subtraction.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"    Figure saved: {FIG_DIR / 'feature_sky_subtraction.pdf'}")


# ===========================================================================
# Feature 2: Polynomial multiplicative calibration fitting
# ===========================================================================
print("\n  [2] Polynomial calibration fitting ...")

# Simulate a multiplicative calibration error: a smooth polynomial response
# function that scales the model (e.g. due to imperfect flat-fielding).
#
# IMPORTANT: the observed data must be constructed from the SAME model that
# the fitter will use (pred_cal, which is the smoothed prediction on the
# observed pixel grid).  Using a different version of the model spectrum
# (e.g. the unsmoothed model_demo) introduces a spurious transfer function
# that cannot be removed by the polynomial fit.
#
# Workflow:
#   1. Build spec_cal (Spectrum object with instrumental smoothing).
#   2. Compute pred_cal = spec_cal.predict(spectrum, csp.wave).
#   3. Apply the true calibration polynomial to pred_cal to get mock data.
#   4. Fit the calibration polynomial using fit_polynomial_calibration.
#   5. Compare recovered polynomial with the true one.

# Set up the Spectrum object and compute the model prediction FIRST
spec_cal = Spectrum(
    wavelength  = wave_demo,
    flux        = jnp.ones(n_demo),   # placeholder — overwritten below
    uncertainty = jnp.ones(n_demo),
    name        = 'calibration_demo',
    smoothtype  = 'vel',
    resolution  = 120.0,
)
spec_cal.setup_for_model(csp.wave)
pred_cal_clean = spec_cal.predict(spectrum, csp.wave)   # true model on obs grid

# True calibration polynomial in the SAME normalised coordinate that
# fit_polynomial_calibration uses, so the recovery is exact up to noise.
wav_mid_cal  = 0.5 * (wdemo_np.max() + wdemo_np.min())
wav_half_cal = 0.5 * (wdemo_np.max() - wdemo_np.min())
x_cal        = (wdemo_np - wav_mid_cal) / wav_half_cal          # ∈ [-1, 1]
true_cal     = 1.0 + 0.30 * x_cal - 0.18 * x_cal**2 + 0.08 * x_cal**3

# Mock observations: smoothed model × calibration polynomial + noise
obs_unc_cal  = jnp.array(0.02 * np.abs(np.array(pred_cal_clean)) + 1e-6)
obs_flux_cal = pred_cal_clean * jnp.array(true_cal) + jnp.array(
    rng_demo.normal(0, np.array(obs_unc_cal))
)

# Rebuild Spectrum with the actual mock data
spec_cal = Spectrum(
    wavelength  = wave_demo,
    flux        = obs_flux_cal,
    uncertainty = obs_unc_cal,
    name        = 'calibration_demo',
    smoothtype  = 'vel',
    resolution  = 120.0,
)
spec_cal.setup_for_model(csp.wave)
pred_cal = spec_cal.predict(spectrum, csp.wave)   # same as pred_cal_clean

# Fit polynomial calibration (order 3 Chebyshev — matches the true polynomial)
coeffs, cal_pred = spec_cal.fit_polynomial_calibration(pred_cal, order=3)
recovered_cal    = np.array(cal_pred) / np.array(pred_cal)

chi2_uncal = spec_cal.chi_sq(pred_cal)
chi2_cal   = float(jnp.sum(
    ((obs_flux_cal - cal_pred) / obs_unc_cal) ** 2
))
print(f"    chi2 without calibration : {chi2_uncal:.1f}")
print(f"    chi2 with    calibration : {chi2_cal:.1f}")
print(f"    Fitted Chebyshev coeffs  : {coeffs}")

C_OBS_CAL   = '#1a4e8a'   # dark blue  — miscalibrated observed data
C_MOD_UNCAL = '#888888'   # mid grey   — uncalibrated model
C_MOD_CAL   = '#c03030'   # red        — calibration-corrected model
C_TRUE_CAL  = '#1a4e8a'   # dark blue  — true calibration curve
C_RECOV_CAL = '#c03030'   # red        — recovered calibration curve

fig, axes = plt.subplots(2, 1, figsize=(9, 7),
                          gridspec_kw={'height_ratios': [2, 1.2]})

# ── Panel 1: observed flux, uncalibrated model, calibration-corrected model ──
ax = axes[0]
ax.plot(wdemo_np, np.array(obs_flux_cal),
        color=C_OBS_CAL, lw=1.1, alpha=0.85, label='Observed (miscalibrated)')
ax.plot(wdemo_np, np.array(pred_cal),
        color=C_MOD_UNCAL, lw=1.0, ls='--', zorder=4, label='Model (no correction)')
ax.plot(wdemo_np, np.array(cal_pred),
        color=C_MOD_CAL, lw=1.3, zorder=5,
        label='Model × fitted P(λ)')
ax.set_ylabel(r'$F_\nu$ (L$_\odot$ Hz$^{-1}$ M$_\odot^{-1}$)')
ax.set_title(
    'Feature 2: Polynomial multiplicative calibration (order-3 Chebyshev)\n'
    fr'$\chi^2$ uncalibrated = {chi2_uncal:.0f},   '
    fr'$\chi^2$ calibrated = {chi2_cal:.0f}',
    fontsize=9,
)
ax.legend(fontsize=8, loc='upper right')
ax.set_xlim(wdemo_np.min(), wdemo_np.max())

# ── Panel 2: true vs recovered calibration polynomial ────────────────
ax = axes[1]
ax.axhline(1.0, color='k', lw=0.5, ls=':')
ax.plot(wdemo_np, true_cal,      color=C_TRUE_CAL,  lw=2.0,
        label='True P(λ)')
ax.plot(wdemo_np, recovered_cal, color=C_RECOV_CAL, lw=1.3, ls='--',
        label='Fitted P(λ) (recovered)')
ax.fill_between(wdemo_np, true_cal, recovered_cal,
                color='#c03030', alpha=0.12, label='Residual error')
ax.set_xlabel(r'Wavelength (\AA)')
ax.set_ylabel('Calibration P(λ)')
ax.legend(fontsize=8, loc='lower right')
ax.set_xlim(wdemo_np.min(), wdemo_np.max())

plt.tight_layout()
plt.savefig(FIG_DIR / "feature_polynomial_calibration.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"    Figure saved: {FIG_DIR / 'feature_polynomial_calibration.pdf'}")


# ===========================================================================
# Feature 3: LOSVD galaxy velocity dispersion
# ===========================================================================
print("\n  [3] LOSVD galaxy velocity dispersion ...")

obs_unc_losvd  = jnp.array(0.02 * np.abs(np.array(model_demo)) + 1e-6)

sigma_losvd_values = [0.0, 100.0, 250.0, 500.0]
losvd_preds        = {}

for sv in sigma_losvd_values:
    if sv == 0.0:
        # No LOSVD — use pure instrumental smoothing as reference
        sp = Spectrum(
            wavelength  = wave_demo,
            flux        = jnp.ones(n_demo),
            uncertainty = jnp.ones(n_demo),
            name        = f'losvd_{int(sv)}',
            smoothtype  = 'vel',
            resolution  = 80.0,
            sigma_losvd = None,
        )
    else:
        sp = Spectrum(
            wavelength  = wave_demo,
            flux        = jnp.ones(n_demo),
            uncertainty = jnp.ones(n_demo),
            name        = f'losvd_{int(sv)}',
            smoothtype  = 'vel',
            resolution  = 80.0,       # fixed instrumental σ = 80 km/s
            sigma_losvd = sv,         # additional galaxy broadening
        )
    sp.setup_for_model(csp.wave)
    losvd_preds[sv] = np.array(sp.predict(spectrum, csp.wave))
    print(f"    sigma_losvd = {sv:5.0f} km/s : predict shape {sp.predict(spectrum, csp.wave).shape}")

cmap3 = plt.get_cmap("plasma")
cp3   = cmap3(np.linspace(0.1, 0.85, len(sigma_losvd_values)))

fig, axes = plt.subplots(2, 1, figsize=(9, 7),
                          gridspec_kw={'height_ratios': [2, 1.2]})

ax = axes[0]
for i, sv in enumerate(sigma_losvd_values):
    lbl = (r'No LOSVD ($\sigma_{\rm inst}=80$ km s$^{-1}$)' if sv == 0
           else fr'$\sigma_{{\rm LOSVD}}={sv:.0f}$ km s$^{{-1}}$ '
                fr'+ $\sigma_{{\rm inst}}=80$ km s$^{{-1}}$')
    lw  = 0.9 if sv == 0 else 1.2
    ls  = '-' if sv == 0 else '--' if sv < 200 else ':'
    ax.plot(wdemo_np, losvd_preds[sv], color=cp3[i], lw=lw, ls=ls, label=lbl)

ax.set_ylabel(r'$F_\nu$ (L$_\odot$ Hz$^{-1}$ M$_\odot^{-1}$)')
ax.set_title('Feature 3: LOSVD galaxy velocity dispersion (stacked with instrumental smoothing)')
ax.legend(fontsize=7, ncol=2)
ax.set_xlim(wdemo_np.min(), wdemo_np.max())

# Zoom onto Hα+[NII] to show progressive broadening
ax = axes[1]
ha_lo2, ha_hi2 = 6500., 6620.
mha2 = (wdemo_np >= ha_lo2) & (wdemo_np <= ha_hi2)
for i, sv in enumerate(sigma_losvd_values):
    lbl = (f'σ_LOSVD = {sv:.0f} km/s' if sv > 0 else 'ref (no LOSVD)')
    ax.plot(wdemo_np[mha2], losvd_preds[sv][mha2], color=cp3[i], lw=1.2, label=lbl)
ax.axvline(6562.8, color='k', lw=0.6, ls=':', alpha=0.5)
ax.text(6563.5, ax.get_ylim()[0] if ax.get_ylim()[0] != 0 else -1e-99,
        r'H$\alpha$', fontsize=7, alpha=0.6)
ax.set_xlim(ha_lo2, ha_hi2)
ax.set_xlabel(r'Wavelength (\AA)')
ax.set_ylabel(r'$F_\nu$')
ax.set_title(r'Zoom: H$\alpha$ region')
ax.legend(fontsize=7, ncol=2)

plt.tight_layout()
plt.savefig(FIG_DIR / "feature_losvd.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"    Figure saved: {FIG_DIR / 'feature_losvd.pdf'}")


# ===========================================================================
# Feature 4: Upper limits on emission lines
# ===========================================================================
print("\n  [4] Emission-line upper limits ...")

# Use the existing lines_obs setup.  Treat [OIII]4959 and [OIII]5007 as
# non-detections (upper limits) in a scenario where a dusty galaxy might
# have suppressed optical lines.
lines_ul = Lines(
    line_ind    = LINE_INDS,
    line_names  = LINE_NAMES,
    wavelength  = LINE_WAVES,
    flux        = line_flux_obs,
    uncertainty = line_unc,
    name        = 'optical_lines_ul',
    upper_limit = jnp.array([False, False, True, True, False]),  # OIII as UL
)
lines_ul.setup_for_model(csp.wave, sigma_v=200.0)
pred_ul = lines_ul.predict(spectrum, csp.wave)

# Compute chi2 for three scenarios:
#   A) Standard chi2 for all lines (no UL treatment)
#   B) One-sided chi2 for OIII lines (UL treatment, model matches data)
#   C) One-sided chi2 when a model over-predicts the upper limit by 2x
pred_ul_overpredict = pred_ul.at[2].set(2.0 * pred_ul[2]).at[3].set(2.0 * pred_ul[3])

chi2_standard = lines_obs.chi_sq(pred_ul)
chi2_ul_ok    = lines_ul.chi_sq(pred_ul)
chi2_ul_bad   = lines_ul.chi_sq(pred_ul_overpredict)

print(f"    chi2 standard  (no UL treatment)         : {chi2_standard:.2f}")
print(f"    chi2 UL mode   (model OK, below limits)  : {chi2_ul_ok:.2f}")
print(f"    chi2 UL mode   (model 2x over limits)    : {chi2_ul_bad:.2f}")

x_lines = np.arange(len(LINE_NAMES))
bar_w2  = 0.25

fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))

ax = axes[0]
ax.bar(x_lines - bar_w2,     np.array(line_flux_obs), bar_w2, yerr=np.array(line_unc),
       color=cpal[5],  capsize=4, label='Observed flux / UL', alpha=0.8, zorder=5)
ax.bar(x_lines,              np.array(pred_ul),        bar_w2,
       color=cpal[19], label='Predicted (fiducial)',       alpha=0.8)
ax.bar(x_lines + bar_w2,     np.array(pred_ul_overpredict), bar_w2,
       color='#c03030', label='Predicted (over-UL × 2)',    alpha=0.8)

for i, ln in enumerate(LINE_NAMES):
    ul_flag = [False, False, True, True, False][i]
    if ul_flag:
        ax.annotate('UL', xy=(x_lines[i], float(line_flux_obs[i]) + float(line_unc[i])),
                    ha='center', fontsize=8, color='#c03030',
                    arrowprops=dict(arrowstyle='->', color='#c03030', lw=1.2),
                    xytext=(x_lines[i], float(line_flux_obs[i]) * 1.4))

ax.set_xticks(x_lines)
ax.set_xticklabels(LINE_NAMES, fontsize=8, rotation=30, ha='right')
ax.set_ylabel('Line flux')
ax.set_title('Feature 4: Emission-line upper limits')
ax.legend(fontsize=7)

ax = axes[1]
chi2_breakdown_std  = [float(((line_flux_obs[i] - pred_ul[i]) / line_unc[i]) ** 2)
                        for i in range(len(LINE_NAMES))]
chi2_breakdown_ul   = [
    float(jnp.where(
        jnp.array([False, False, True, True, False])[i] & ((line_flux_obs[i] - pred_ul_overpredict[i]) < 0),
        ((line_flux_obs[i] - pred_ul_overpredict[i]) / line_unc[i]) ** 2,
        0.0 if [False, False, True, True, False][i] else
        ((line_flux_obs[i] - pred_ul_overpredict[i]) / line_unc[i]) ** 2
    ))
    for i in range(len(LINE_NAMES))
]

ax.bar(x_lines - bar_w2 / 2, chi2_breakdown_std, bar_w2,
       color=cpal[5],  label=r'$\chi^2$ standard',   alpha=0.8)
ax.bar(x_lines + bar_w2 / 2, chi2_breakdown_ul,  bar_w2,
       color='#c03030', label=r'$\chi^2$ UL (over-prediction)', alpha=0.8)
ax.set_xticks(x_lines)
ax.set_xticklabels(LINE_NAMES, fontsize=8, rotation=30, ha='right')
ax.set_ylabel(r'$\chi^2$ contribution')
ax.set_title(r'Per-line $\chi^2$: standard vs. upper-limit treatment')
ax.legend(fontsize=7)

plt.tight_layout()
plt.savefig(FIG_DIR / "feature_upper_limits.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"    Figure saved: {FIG_DIR / 'feature_upper_limits.pdf'}")


# ===========================================================================
# Feature 5: Noise floor / fractional uncertainty
# ===========================================================================
print("\n  [5] Noise floor (fractional uncertainty) ...")

obs_unc_nf   = jnp.array(0.01 * np.abs(np.array(model_demo)) + 1e-6)  # 1% noise
obs_flux_nf  = model_demo + jnp.array(rng_demo.normal(0, np.array(obs_unc_nf)))

noise_floor_values = [0.0, 0.02, 0.05, 0.10]
chi2_nf_list       = []

spec_base_nf = Spectrum(
    wavelength  = wave_demo,
    flux        = obs_flux_nf,
    uncertainty = obs_unc_nf,
    name        = 'nf_demo_base',
    smoothtype  = 'vel',
    resolution  = 120.0,
    noise_floor = 0.0,
)
spec_base_nf.setup_for_model(csp.wave)
pred_nf = spec_base_nf.predict(spectrum, csp.wave)

for nf in noise_floor_values:
    sp = Spectrum(
        wavelength  = wave_demo,
        flux        = obs_flux_nf,
        uncertainty = obs_unc_nf,
        name        = f'nf_{nf:.2f}',
        smoothtype  = 'vel',
        resolution  = 120.0,
        noise_floor = nf,
    )
    sp.setup_for_model(csp.wave)
    chi2_nf_list.append(sp.chi_sq(pred_nf))
    print(f"    noise_floor = {nf:.2f}  ->  chi2 = {chi2_nf_list[-1]:.1f}")

sigma_eff_0pct  = np.array(obs_unc_nf)
sigma_eff_2pct  = np.sqrt(np.array(obs_unc_nf)**2 + (0.02 * np.abs(np.array(pred_nf)))**2)
sigma_eff_5pct  = np.sqrt(np.array(obs_unc_nf)**2 + (0.05 * np.abs(np.array(pred_nf)))**2)
sigma_eff_10pct = np.sqrt(np.array(obs_unc_nf)**2 + (0.10 * np.abs(np.array(pred_nf)))**2)

# Noise-floor inflation factor: sigma_eff / sigma_photon
# This clearly shows WHERE in the spectrum the floor dominates.
# When the floor is negligible the ratio ≈ 1; when it dominates it rises.
infl_2pct  = sigma_eff_2pct  / sigma_eff_0pct
infl_5pct  = sigma_eff_5pct  / sigma_eff_0pct
infl_10pct = sigma_eff_10pct / sigma_eff_0pct

# Colours: perceptually ordered (low → high floor)
NF_COLORS = ['#888888', '#4575b4', '#d73027', '#a50026']

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

# ── Left: chi-squared vs noise floor ─────────────────────────────────
ax = axes[0]
bars = ax.bar(np.arange(len(noise_floor_values)), chi2_nf_list,
              color=NF_COLORS, alpha=0.88, edgecolor='k', lw=0.6, width=0.55)
for bar, chi2 in zip(bars, chi2_nf_list):
    ax.text(bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.01 * max(chi2_nf_list),
            f'{chi2:.0f}', ha='center', va='bottom', fontsize=8)
ax.set_xticks(np.arange(len(noise_floor_values)))
ax.set_xticklabels([f'{nf:.0%}' for nf in noise_floor_values], fontsize=9)
ax.set_xlabel('Noise floor fraction $f_{\\rm floor}$', fontsize=9)
ax.set_ylabel(r'$\chi^2$', fontsize=9)
ax.set_title('Feature 5: Noise floor — total $\\chi^2$\n(same data, same model, varying floor)',
             fontsize=9)
ax.set_ylim(0, max(chi2_nf_list) * 1.15)

# ── Right: inflation factor sigma_eff / sigma_photon vs wavelength ───
ax = axes[1]
ax.axhline(1.0, color='k', lw=0.6, ls=':', label='No inflation (floor = 0)')
ax.plot(wdemo_np, infl_2pct,  color=NF_COLORS[1], lw=1.3,
        label=r'$f_{\rm floor}=2\%$')
ax.plot(wdemo_np, infl_5pct,  color=NF_COLORS[2], lw=1.5,
        label=r'$f_{\rm floor}=5\%$')
ax.plot(wdemo_np, infl_10pct, color=NF_COLORS[3], lw=2.0,
        label=r'$f_{\rm floor}=10\%$')

# Mark the crossover wavelength where floor = photon noise for each case
for infl, col, nf in [(infl_2pct, NF_COLORS[1], 0.02),
                       (infl_5pct, NF_COLORS[2], 0.05),
                       (infl_10pct, NF_COLORS[3], 0.10)]:
    # crossover where inflation > sqrt(2) (floor equals photon noise)
    cross_idx = np.where(infl > np.sqrt(2))[0]
    if len(cross_idx):
        wx = wdemo_np[cross_idx[0]]
        ax.axvline(wx, color=col, lw=0.7, ls='--', alpha=0.5)

ax.set_xlabel(r'Wavelength (\AA)', fontsize=9)
ax.set_ylabel(r'$\sigma_{\rm eff}\,/\,\sigma_{\rm photon}$', fontsize=9)
ax.set_title(r'Noise floor inflation factor'
             '\n'
             r'$\sigma_{\rm eff}^2 = \sigma_{\rm photon}^2 + (f_{\rm floor}\,|m|)^2$',
             fontsize=9)
ax.legend(fontsize=8, loc='upper left')
ax.set_xlim(wdemo_np.min(), wdemo_np.max())
ax.set_ylim(bottom=0.95)

plt.tight_layout()
plt.savefig(FIG_DIR / "feature_noise_floor.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"    Figure saved: {FIG_DIR / 'feature_noise_floor.pdf'}")


# ===========================================================================
# Feature 6: Gaussian Process noise model
# ===========================================================================
print("\n  [6] Gaussian Process noise model ...")

# Simulate correlated residuals: add a slowly-varying systematic offset
# on top of the Gaussian noise, which a GP can model.
sys_length   = 200.0   # Å correlation length
sys_amp      = 0.04 * float(jnp.median(model_demo))

# Build a simple correlated systematic by drawing from a GP prior
wdemo_np_f64  = wdemo_np.astype(np.float64)
K_sys         = (sys_amp ** 2) * np.exp(
    -0.5 * (wdemo_np_f64[:, None] - wdemo_np_f64[None, :]) ** 2
    / sys_length ** 2
)
K_sys        += 1e-8 * np.eye(n_demo)
L_sys         = np.linalg.cholesky(K_sys)
systematic    = L_sys @ rng_demo.standard_normal(n_demo)

obs_unc_gp   = jnp.array(0.015 * np.abs(np.array(model_demo)) + 1e-6)
obs_flux_gp  = model_demo + jnp.array(systematic) + jnp.array(
    rng_demo.normal(0, np.array(obs_unc_gp))
)

# Spectrum without GP: standard Gaussian chi-squared
spec_no_gp = Spectrum(
    wavelength  = wave_demo,
    flux        = obs_flux_gp,
    uncertainty = obs_unc_gp,
    name        = 'gp_demo_no_gp',
    smoothtype  = 'vel',
    resolution  = 120.0,
    noise       = None,
)
spec_no_gp.setup_for_model(csp.wave)
pred_gp = spec_no_gp.predict(spectrum, csp.wave)

log_ll_no_gp = spec_no_gp.log_likelihood(pred_gp)

# Spectrum with GP: GP models the correlated systematic
gp_noise  = GaussianProcess(amplitude=0.05, length_scale=sys_length)
spec_gp   = Spectrum(
    wavelength  = wave_demo,
    flux        = obs_flux_gp,
    uncertainty = obs_unc_gp,
    name        = 'gp_demo',
    smoothtype  = 'vel',
    resolution  = 120.0,
    noise       = gp_noise,
)
spec_gp.setup_for_model(csp.wave)
log_ll_gp_correct = spec_gp.log_likelihood(pred_gp)

# Misspecified GP (very short length scale — cannot capture the systematic)
gp_noise_wrong  = GaussianProcess(amplitude=0.05, length_scale=10.0)
spec_gp_wrong   = Spectrum(
    wavelength  = wave_demo,
    flux        = obs_flux_gp,
    uncertainty = obs_unc_gp,
    name        = 'gp_demo_wrong',
    smoothtype  = 'vel',
    resolution  = 120.0,
    noise       = gp_noise_wrong,
)
spec_gp_wrong.setup_for_model(csp.wave)
log_ll_gp_wrong = spec_gp_wrong.log_likelihood(pred_gp)

print(f"    log-likelihood (no GP)              : {log_ll_no_gp:.1f}")
print(f"    log-likelihood (correct GP ℓ={sys_length:.0f} Å) : {log_ll_gp_correct:.1f}")
print(f"    log-likelihood (wrong   GP ℓ=10 Å)  : {log_ll_gp_wrong:.1f}")
print(f"    GP repr: {gp_noise}")

fig, axes = plt.subplots(2, 1, figsize=(9, 6),
                          gridspec_kw={'height_ratios': [2, 1]})

ax = axes[0]
ax.plot(wdemo_np, np.array(obs_flux_gp),
        color=cpal[5],  lw=1.0, alpha=0.8, label='Observed (+ correlated systematic)')
ax.plot(wdemo_np, np.array(pred_gp),
        color=cpal[19], lw=1.0, ls='--', label='Model prediction')
ax.fill_between(wdemo_np,
                np.array(pred_gp) - np.array(obs_unc_gp),
                np.array(pred_gp) + np.array(obs_unc_gp),
                color=cpal[19], alpha=0.15, label=r'$\pm 1\sigma$ (white noise)')
ax.fill_between(wdemo_np,
                np.array(pred_gp) - np.array(obs_unc_gp) - sys_amp,
                np.array(pred_gp) + np.array(obs_unc_gp) + sys_amp,
                color='#e8c560', alpha=0.18, label=r'$\pm 1\sigma$ (+ GP systematic)')
ax.set_ylabel(r'$F_\nu$ (L$_\odot$ Hz$^{-1}$ M$_\odot^{-1}$)')
ax.set_title(
    f'Feature 6: Gaussian Process noise model  '
    f'(amplitude={gp_noise.amplitude}, length_scale={gp_noise.length_scale} Å)\n'
    f'log-likelihood:  no GP = {log_ll_no_gp:.0f} '
    f'  correct GP = {log_ll_gp_correct:.0f} '
    f'  wrong GP = {log_ll_gp_wrong:.0f}'
)
ax.legend(fontsize=7, ncol=2)

ax = axes[1]
resid_gp = np.array(spec_no_gp.residuals(pred_gp))
ax.axhline(0, color='k', lw=0.6, ls=':')
ax.plot(wdemo_np, resid_gp, color=cpal[5], lw=0.8, label='Residuals (data − model) / σ')
ax.fill_between(wdemo_np, -1, 1, color='0.85', alpha=0.5, label=r'$\pm 1\sigma$')
ax.set_xlabel(r'Wavelength (\AA)')
ax.set_ylabel(r'$(d-m)/\sigma$')
ax.set_ylim(-6, 6)
ax.legend(fontsize=7)

plt.tight_layout()
plt.savefig(FIG_DIR / "feature_gp_noise.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"    Figure saved: {FIG_DIR / 'feature_gp_noise.pdf'}")


# ===========================================================================
# Summary panel: all 6 features in one figure
# ===========================================================================
print("\n  Generating summary panel ...")

fig, axes = plt.subplots(2, 3, figsize=(14, 8))
axes = axes.ravel()

# Panel 0: Sky subtraction — residuals
ax = axes[0]
ax.fill_between(wdemo_np, -1, 1, color='0.88', alpha=0.5)
ax.axhline(0, color='k', lw=0.5, ls=':')
ax.plot(wdemo_np, resid_raw,  color=C_OBS,  lw=0.7, alpha=0.85, label='w/o sky sub')
ax.plot(wdemo_np, resid_sky,  color=C_SUB,  lw=0.9, label='with sky sub')
ax.set_ylim(-8, 8)
ax.set_title('1: Sky subtraction', fontsize=9)
ax.set_xlabel(r'Wavelength (\AA)', fontsize=7)
ax.set_ylabel(r'$(d-m)/\sigma$', fontsize=7)
ax.legend(fontsize=6)

# Panel 1: Polynomial calibration — recovered vs true
ax = axes[1]
ax.axhline(1.0, color='k', lw=0.5, ls=':')
ax.plot(wdemo_np, true_cal,      color=C_TRUE_CAL,  lw=1.8, label='True P(λ)')
ax.plot(wdemo_np, recovered_cal, color=C_RECOV_CAL, lw=1.2, ls='--', label='Fitted P(λ)')
ax.set_title('2: Polynomial calibration', fontsize=9)
ax.set_xlabel(r'Wavelength (\AA)', fontsize=7)
ax.set_ylabel('Calibration P(λ)', fontsize=7)
ax.legend(fontsize=6)

# Panel 2: LOSVD — Hα zoom
ax = axes[2]
for i, sv in enumerate(sigma_losvd_values):
    ax.plot(wdemo_np[mha2], losvd_preds[sv][mha2], color=cp3[i], lw=1.1,
            label=f'σ={sv:.0f} km/s')
ax.axvline(6562.8, color='k', lw=0.6, ls=':', alpha=0.5)
ax.set_xlim(ha_lo2, ha_hi2)
ax.set_title(r'3: LOSVD ($H\alpha$ zoom)', fontsize=9)
ax.set_xlabel(r'Wavelength (\AA)', fontsize=7)
ax.set_ylabel(r'$F_\nu$', fontsize=7)
ax.legend(fontsize=6)

# Panel 3: Upper limits — line fluxes
ax = axes[3]
bw = 0.3
xp = np.arange(len(LINE_NAMES))
ax.bar(xp - bw / 2, np.array(line_flux_obs), bw, yerr=np.array(line_unc),
       color=cpal[5], capsize=3, alpha=0.8, label='Observed / UL')
ax.bar(xp + bw / 2, np.array(pred_ul_overpredict), bw,
       color='#c03030', alpha=0.8, label='Model (2× UL)')
for i in [2, 3]:
    ax.annotate('UL', xy=(xp[i] - bw / 2, float(line_flux_obs[i])),
                ha='center', fontsize=7, color='#c03030')
ax.set_xticks(xp)
ax.set_xticklabels(LINE_NAMES, fontsize=7, rotation=30, ha='right')
ax.set_title('4: Emission-line upper limits', fontsize=9)
ax.set_ylabel('Line flux', fontsize=7)
ax.legend(fontsize=6)

# Panel 4: Noise floor — inflation factor sigma_eff / sigma_photon
ax = axes[4]
ax.axhline(1.0, color='k', lw=0.5, ls=':')
ax.plot(wdemo_np, infl_2pct,  color=NF_COLORS[1], lw=1.1, label='2%')
ax.plot(wdemo_np, infl_5pct,  color=NF_COLORS[2], lw=1.3, label='5%')
ax.plot(wdemo_np, infl_10pct, color=NF_COLORS[3], lw=1.5, label='10%')
ax.set_title('5: Noise floor', fontsize=9)
ax.set_xlabel(r'Wavelength (\AA)', fontsize=7)
ax.set_ylabel(r'$\sigma_{\rm eff}/\sigma_{\rm phot}$', fontsize=7)
ax.set_ylim(bottom=0.95)
ax.legend(fontsize=6, title='Floor')

# Panel 5: GP residuals
ax = axes[5]
ax.axhline(0, color='k', lw=0.5, ls=':')
ax.plot(wdemo_np, resid_gp, color=cpal[5], lw=0.7)
ax.fill_between(wdemo_np, -1, 1, color='0.85', alpha=0.4)
ax.text(0.05, 0.88, f'log L (no GP) = {log_ll_no_gp:.0f}',
        transform=ax.transAxes, fontsize=7)
ax.text(0.05, 0.78, f'log L (GP) = {log_ll_gp_correct:.0f}',
        transform=ax.transAxes, fontsize=7, color=cpal[19])
ax.set_title('6: GP noise model', fontsize=9)
ax.set_xlabel(r'Wavelength (\AA)', fontsize=7)
ax.set_ylabel(r'$(d-m)/\sigma$', fontsize=7)
ax.set_ylim(-6, 6)

plt.suptitle('Ceridwen observation.py — Prospector-parity features', fontsize=11, y=1.01)
plt.tight_layout()
plt.savefig(FIG_DIR / "prospector_parity_summary.pdf", dpi=150, bbox_inches='tight')
plt.close()
print(f"  Summary figure saved: {FIG_DIR / 'prospector_parity_summary.pdf'}")
print("\n  All 6 Prospector-parity features demonstrated successfully.")


# ============================================================================
# Feature 7: Parameter transforms — logsfr_ratios parametrisation
# ============================================================================
# Demonstrates the depends_on / transforms mechanism in SedModel.
# Instead of fitting the raw SFH weight vector ``sfh`` directly, we fit
# n_time-1 log-ratios of consecutive SFR bins:
#
#     logsfr_ratios[i] = log10( SFR[i] / SFR[i+1] )
#
# This constrains the SFH to be smooth and physically sensible (Leja+2019).
# The transform is registered at SedModel construction time; the sampler
# never sees the raw sfh vector.
# ============================================================================

print("\n" + "=" * 60)
print("Feature 7: Parameter transforms (logsfr_ratios)")
print("=" * 60)

from ceridwen.model.transforms import logsfr_ratios_to_sfh, sfh_to_logsfr_ratios

# ── 7.1  SFH shapes produced by different logsfr_ratios vectors ──────────────
print("  7.1  Mapping logsfr_ratios → SFH shapes …")

# Lookback-time grid for the demo CSP (in years, as stored in csp.sfh_times)
sfh_times_yr_demo = np.array(csp.sfh_times)          # shape (N_TIME,)
lookback_gyr_demo = sfh_times_yr_demo / 1e9           # Gyr (for plotting)

N_TR = csp.n_time   # number of SFH bins

# Five physically motivated ratio vectors
# (positive = older dominates; negative = younger dominates)
tr_scenarios = {
    "Flat (no ratios)"       : np.zeros(N_TR - 1),
    "Declining (early type)" : np.full(N_TR - 1, +0.8),
    "Rising (late assembly)" : np.full(N_TR - 1, -0.8),
    "Recent burst"           : np.concatenate([np.full(N_TR - 2, +0.3),
                                                np.array([-2.5])]),
    "Ancient burst"          : np.concatenate([np.array([+3.0]),
                                                np.full(N_TR - 2, -0.2)]),
}

sfh_shapes = {}
for label, ratios in tr_scenarios.items():
    sfh_shapes[label] = np.array(
        logsfr_ratios_to_sfh(ratios, sfh_times_yr=sfh_times_yr_demo)
    )

# ── 7.2  Build a SedModel with the logsfr_ratios transform ───────────────────
print("  7.2  Building SedModel with logsfr_ratios transform …")

# Synthetic spectrum observation over the demo wavelength range
wave_demo_tr = np.linspace(4000, 9000, 400)
dummy_flux   = np.ones(len(wave_demo_tr))
dummy_unc    = np.full(len(wave_demo_tr), 1e-3)

spec_tr = Spectrum(
    wavelength  = wave_demo_tr,
    flux        = dummy_flux,
    uncertainty = dummy_unc,
    name        = "demo_transform_spec",
    resolution  = 120.0,
    res_type    = "vel",
)

# Flat SFH as initial free-parameter values (zero log-ratios)
init_logsfr_ratios = np.zeros(N_TR - 1)

def _logsfr_ratios_transform(free_theta,
                               _sfh_times=sfh_times_yr_demo):
    return logsfr_ratios_to_sfh(free_theta["logsfr_ratios"],
                                 sfh_times_yr=_sfh_times)
_logsfr_ratios_transform.__name__ = "logsfr_ratios_to_sfh"

model_tr = SedModel(
    csp,
    observations    = [spec_tr],
    priors          = {},          # no explicit priors for this demo
    transforms      = {"sfh": _logsfr_ratios_transform},
    free_param_init = {"logsfr_ratios": jnp.array(init_logsfr_ratios)},
)

print("  Summary of transformed SedModel:")
print(model_tr.summary())
print()

# Verify that param_names no longer contains 'sfh' and now contains
# 'logsfr_ratios'
assert "sfh" not in model_tr.param_names, \
    "ERROR: 'sfh' should be removed from free-parameter list"
assert "logsfr_ratios" in model_tr.param_names, \
    "ERROR: 'logsfr_ratios' should be added to free-parameter list"
print("  Parameter bookkeeping: PASS "
      f"(free params: {model_tr.param_names})")

# ── 7.3  Forward-predict spectra for each SFH scenario ───────────────────────
print("  7.3  Predicting spectra for all scenarios …")

base_free_theta = {k: jnp.array(v)
                   for k, v in model_tr.theta_init.items()
                   if k != "logsfr_ratios"}

scenario_spectra = {}
for label, ratios in tr_scenarios.items():
    free_theta_sc = dict(base_free_theta)
    free_theta_sc["logsfr_ratios"] = jnp.array(ratios)
    pred_dict = model_tr.predict(free_theta_sc)
    scenario_spectra[label] = np.array(pred_dict["demo_transform_spec"])

# ── 7.4  Round-trip test: sfh → ratios → sfh ─────────────────────────────────
print("  7.4  Round-trip test: sfh → sfh_to_logsfr_ratios → logsfr_ratios_to_sfh …")

test_sfh = np.array(sfh_shapes["Declining (early type)"])
recovered_ratios = np.array(sfh_to_logsfr_ratios(test_sfh))
recovered_sfh    = np.array(
    logsfr_ratios_to_sfh(recovered_ratios, sfh_times_yr=sfh_times_yr_demo)
)
max_err = float(np.max(np.abs(test_sfh - recovered_sfh)))
print(f"    Max round-trip error: {max_err:.2e}")
assert max_err < 1e-5, f"Round-trip error too large: {max_err:.2e}"
print("  Round-trip test: PASS")

# ── 7.5  Gradient test: d(spectrum)/d(logsfr_ratios) via JAX ─────────────────
print("  7.5  Gradient test via jax.grad …")

def _loss_fn(logsfr_ratios_vec):
    ft = dict(base_free_theta)
    ft["logsfr_ratios"] = logsfr_ratios_vec
    pred = model_tr.predict(ft)["demo_transform_spec"]
    return jnp.sum(pred)

try:
    grad_fn = jax.grad(_loss_fn)
    grad_val = grad_fn(jnp.zeros(N_TR - 1))
    assert grad_val.shape == (N_TR - 1,), "Gradient shape mismatch"
    print(f"    Gradient shape: {grad_val.shape}  "
          f"max|grad| = {float(jnp.max(jnp.abs(grad_val))):.4e}")
    print("  Gradient test: PASS — jax.grad flows through transform")
    _grad_ok = True
except Exception as e:
    print(f"  Gradient test: SKIPPED ({e})")
    grad_val   = np.zeros(N_TR - 1)
    _grad_ok   = False

# ── 7.6  Figure ───────────────────────────────────────────────────────────────
print("  7.6  Generating figure …")

# Colour palette for scenarios
_sc_colors = ['#1f77b4', '#d62728', '#2ca02c', '#9467bd', '#8c564b']
_sc_labels  = list(tr_scenarios.keys())

fig7, axes7 = plt.subplots(1, 3, figsize=(13, 4.2))
fig7.suptitle(
    r"Feature 7: logsfr\_ratios parameter transform",
    fontsize=11, y=1.02,
)

# Panel A: SFH shapes (SFR vs lookback time)
ax7a = axes7[0]
for ci, (label, sfh_arr) in enumerate(sfh_shapes.items()):
    # Normalise to peak = 1 for visual comparison
    sfh_norm = sfh_arr / float(np.max(sfh_arr))
    ax7a.plot(lookback_gyr_demo, sfh_norm,
              color=_sc_colors[ci], lw=1.6, label=label)
ax7a.set_xlabel(r'Lookback time [Gyr]', fontsize=9)
ax7a.set_ylabel(r'Relative SFR (normalised)', fontsize=9)
ax7a.set_title('(a) SFH shapes', fontsize=10)
ax7a.legend(fontsize=6.5, loc='upper right')
ax7a.axhline(0, color='k', lw=0.4, ls=':')

# Panel B: resulting spectra (zoomed into optical range, f_nu)
ax7b = axes7[1]
# Restrict to demo wavelength range for clarity
for ci, (label, spec_arr) in enumerate(scenario_spectra.items()):
    # Normalise to median for shape comparison
    med = float(np.median(spec_arr[spec_arr > 0])) if np.any(spec_arr > 0) else 1.0
    ax7b.plot(wave_demo_tr, spec_arr / med,
              color=_sc_colors[ci], lw=0.9, alpha=0.85, label=label)
ax7b.set_xlabel(r'Wavelength [\AA]', fontsize=9)
ax7b.set_ylabel(r'$F_\nu$ (normalised)', fontsize=9)
ax7b.set_title('(b) Predicted spectra', fontsize=10)
ax7b.legend(fontsize=6.5, loc='upper right')

# Panel C: logsfr_ratios values for each scenario
ax7c = axes7[2]
idx   = np.arange(N_TR - 1)
for ci, (label, ratios) in enumerate(tr_scenarios.items()):
    ax7c.plot(idx, ratios, 'o-', color=_sc_colors[ci], lw=1.2,
              markersize=4, label=label)
ax7c.axhline(0, color='k', lw=0.5, ls=':')
ax7c.set_xlabel(r'Ratio index $i$', fontsize=9)
ax7c.set_ylabel(r'$\log_{10}(\mathrm{SFR}_i / \mathrm{SFR}_{i+1})$', fontsize=9)
ax7c.set_title(r'(c) $\log$ SFR ratios', fontsize=10)
ax7c.legend(fontsize=6.5)
ax7c.set_xticks(idx)

plt.tight_layout()
fig7.savefig(FIG_DIR / "feature_logsfr_ratios.pdf",
             dpi=150, bbox_inches='tight')
plt.close(fig7)
print(f"  Saved: {FIG_DIR / 'feature_logsfr_ratios.pdf'}")

# ── 7.7  PGM diagram showing the transform layer ─────────────────────────────
print("  7.7  Generating transformed-model PGM diagram …")
fig_pgm, ax_pgm = model_tr.display(return_fig=True)
fig_pgm.savefig(FIG_DIR / "feature_logsfr_ratios_pgm.pdf",
                dpi=150, bbox_inches='tight')
plt.close(fig_pgm)
print(f"  Saved: {FIG_DIR / 'feature_logsfr_ratios_pgm.pdf'}")

print("\n  Feature 7 demonstration complete.")
