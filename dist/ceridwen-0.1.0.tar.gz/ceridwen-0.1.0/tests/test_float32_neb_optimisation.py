#!/usr/bin/env python
"""
test_float32_neb_optimisation.py
=================================
Comprehensive test suite for the float32 forward-model and vectorised-nebular
(evaluate_batch) optimisations in ceridwen.

Platform handling
-----------------
- **Mac (CPU check):**  Forces JAX onto the CPU backend (Apple Metal does not
  support float64).  Timing numbers are informational only — the real speedup
  shows up on GPU.
- **Tursa (GPU check):**  Uses the CUDA/GPU backend.  Timing results are
  representative.

Usage
-----
    # Mac — quick sanity check
    python ceridwen/csp/test_float32_neb_optimisation.py

    # Tursa — full GPU benchmark
    python ceridwen/csp/test_float32_neb_optimisation.py --gpu

Tests
-----
1. Output dtype is float32 for every spectrum model variant.
2. evaluate_batch vs element-wise vmap(evaluate) — nebular accuracy.
3. Full spectrum: evaluate_batch path vs old vmap path.
4. Timing: new (float32 + evaluate_batch) vs old (vmap) for nebular
   scenarios, plus float32-only vs baseline for dust-only scenarios.
5. FSPS big_comparison validation (skipped if fsps not importable).
6. Gradient correctness (jax.grad through the optimised forward model).
"""

# ── Force CPU on Mac BEFORE importing JAX ────────────────────────────────────
import os
import sys
import platform

_on_mac = (platform.system() == "Darwin")
_want_gpu = ("--gpu" in sys.argv)

if _on_mac and not _want_gpu:
    # Metal backend lacks float64 and is experimental — force CPU for the
    # correctness tests.  On Tursa the CUDA backend is picked up automatically.
    os.environ.setdefault("JAX_PLATFORMS", "cpu")

# Now safe to import JAX
import time
import pathlib

import numpy as np
import jax
import jax.numpy as jnp
from jax import vmap

# Enable float64 on CPU so the reference (old-path) comparison is meaningful.
jax.config.update("jax_enable_x64", True)

# ── Paths ────────────────────────────────────────────────────────────────────
from _gridfixture import require_test_grid

_HOME = pathlib.Path.home()
SSP_FILE = str(require_test_grid())
SPS_HOME = os.environ.get("SPS_HOME")

FIG_DIR = pathlib.Path(__file__).parent / "figures"
FIG_DIR.mkdir(exist_ok=True)

# ── Load SSP data ────────────────────────────────────────────────────────────
from ceridwen.ssps.ssp_data import SSPData
from ceridwen.csp.csp import CSPBasis

print(f"Loading SSP data from {SSP_FILE} ...")
ssp_data = SSPData.load(SSP_FILE)

# ── Common SFH setup ────────────────────────────────────────────────────────
T_UNIV = 13.8
N_TIME = 10
t_grid   = jnp.linspace(1e-2, T_UNIV, N_TIME)
lookback = jnp.linspace(0.0, T_UNIV, N_TIME)   # NEW convention


def gaussian_burst(tau, center, width, amp=1.0):
    return amp * jnp.exp(-0.5 * ((tau - center) / width) ** 2)


sfr_bimodal = (gaussian_burst(lookback, 0.05, 0.03, 1.0) +
               gaussian_burst(lookback, 11.0, 0.8,  0.7))

DUST_BIN_PARAMS = {
    'bin_edges': [(-jnp.inf, -1.97)],
    'laws':      ['powerlaw'],
}

BASE_THETA = {
    'lookback_time': lookback,
    'sfh':           sfr_bimodal,
    'Z':             jnp.array([jnp.log10(0.0002)]),
}

DIFFUSE_TAU   = 2.0
DIFFUSE_INDEX = -0.7
GAS_LOGZ      = 0.0
GAS_LOGU      = -2.0


# ═══════════════════════════════════════════════════════════════════════════
# Helper
# ═══════════════════════════════════════════════════════════════════════════

def make_csp(add_dust, add_diffuse_dust, add_dust_emission, add_neb,
             verbose=False):
    return CSPBasis(
        ssp_data,
        theta             = BASE_THETA.copy(),
        tuniv             = T_UNIV,
        tiny_logt         = -70,
        zh_const          = True,
        add_dust          = add_dust,
        add_diffuse_dust  = add_diffuse_dust,
        add_dust_emission = add_dust_emission,
        add_neb           = add_neb,
        init_neb_params   = {'isoc_type': 'mist', 'cloudy_dust': False},
        init_dust_params  = DUST_BIN_PARAMS,
        diffuse_law       = 'kriek_conroy',
        sps_home          = SPS_HOME,
        verbose           = verbose,
        sfh_interp        = 'linear',
    )


def _fill_theta(theta):
    """Fill in default physical values for dust/neb params if present."""
    t = theta.copy()
    if 'gas_logz' in t:
        t['gas_logz'] = jnp.array([GAS_LOGZ])
        t['gas_logu'] = jnp.array([GAS_LOGU])
    if 'diffuse_tau_kc' in t:
        t['diffuse_tau_kc']     = DIFFUSE_TAU
        t['diffuse_dust_index'] = DIFFUSE_INDEX
    return t


# ═══════════════════════════════════════════════════════════════════════════
# TEST 1: Output dtype is float32
# ═══════════════════════════════════════════════════════════════════════════

def test_output_dtype():
    print("\n" + "=" * 70)
    print("TEST 1: Output dtype verification")
    print("=" * 70)

    scenarios = {
        "stellar only": dict(add_dust=False, add_diffuse_dust=False,
                             add_dust_emission=False, add_neb=False),
        "dust only":    dict(add_dust=True,  add_diffuse_dust=True,
                             add_dust_emission=False, add_neb=False),
        "neb only":     dict(add_dust=False, add_diffuse_dust=False,
                             add_dust_emission=False, add_neb=True),
        "dust + neb":   dict(add_dust=True,  add_diffuse_dust=True,
                             add_dust_emission=False, add_neb=True),
    }

    all_pass = True
    for label, kw in scenarios.items():
        csp  = make_csp(**kw)
        spec = csp.get_spectrum(_fill_theta(csp.theta_init))
        ok   = (spec.dtype == jnp.float32)
        tag  = "PASS" if ok else "FAIL"
        if not ok:
            all_pass = False
        print(f"  [{tag}] {label:25s}  dtype = {spec.dtype}")

    return all_pass


# ═══════════════════════════════════════════════════════════════════════════
# TEST 2: evaluate_batch vs element-wise vmap(evaluate) — nebular accuracy
# ═══════════════════════════════════════════════════════════════════════════

def test_nebular_batch_accuracy():
    print("\n" + "=" * 70)
    print("TEST 2: evaluate_batch vs vmap(evaluate) — nebular accuracy")
    print("=" * 70)

    csp = make_csp(add_dust=True, add_diffuse_dust=True,
                   add_dust_emission=False, add_neb=True)

    test_points = [
        ( 0.0, -2.0, "on-grid centre"),
        (-0.5, -2.5, "off-grid interpolation"),
        ( 0.3, -1.5, "near upper edge"),
        (-1.0, -3.5, "near lower edge"),
    ]

    all_pass = True
    for logZ, logU, label in test_points:
        _logZ = jnp.array([logZ])
        _logU = jnp.array([logU])

        # --- new vectorised path (evaluate_batch) ---
        neb_batch = csp.neb.evaluate_batch(
            _logZ, _logU, csp._neb_ages_young, csp._neb_logqq_young
        )
        # shape: (n_z_ssp, n_young, nspec)

        # --- reference: element-wise vmap(evaluate) ---
        def nebular_one(logage, logQ):
            return csp.neb.evaluate(logZ=_logZ, logU=_logU,
                                    logage=logage, logQ=logQ)

        neb_cont_y, neb_lines_y = vmap(
            lambda logQ_row: vmap(nebular_one)(csp._neb_ages_young, logQ_row)
        )(csp._neb_logqq_young)
        neb_direct = (neb_cont_y + neb_lines_y)[..., 0]   # squeeze trailing (1,)

        # --- compare ---
        neb_direct_f32 = neb_direct.astype(jnp.float32)
        neb_batch_f32  = neb_batch.astype(jnp.float32)
        denom   = jnp.abs(neb_direct_f32) + 1e-30
        rel_err = jnp.abs(neb_batch_f32 - neb_direct_f32) / denom
        max_re  = float(jnp.max(rel_err))
        mean_re = float(jnp.mean(rel_err))

        # evaluate_batch factors the same trilinear interpolation, so the
        # result should be numerically identical up to float32 rounding.
        tol = 1e-5
        ok  = max_re < tol
        tag = "PASS" if ok else "FAIL"
        if not ok:
            all_pass = False
        print(f"  [{tag}] ({logZ:+.1f}, {logU:+.1f}) {label:25s}  "
              f"max_rel = {max_re:.2e}  mean = {mean_re:.2e}")

    return all_pass


# ═══════════════════════════════════════════════════════════════════════════
# TEST 3: Full spectrum — evaluate_batch path vs old vmap reference
# ═══════════════════════════════════════════════════════════════════════════

def test_precision_comparison():
    print("\n" + "=" * 70)
    print("TEST 3: Full spectrum — evaluate_batch vs vmap reference")
    print("=" * 70)

    csp   = make_csp(add_dust=True, add_diffuse_dust=True,
                     add_dust_emission=False, add_neb=True)
    theta = _fill_theta(csp.theta_init)

    # New path (evaluate_batch — the default now)
    spec_new = csp.get_spectrum(theta)

    # Reference: manually compute the nebular via the old vmap path and
    # assemble the spectrum.  We replicate the logic that was previously
    # inside get_spectrum_dattn_nodem_neb's vmap branch.
    W = csp.calculate_ssp_weights(theta=theta)
    logZ_gas = theta["gas_logz"]
    logU     = theta["gas_logu"]

    def nebular_one(logage, logQ):
        return csp.neb.evaluate(logZ=logZ_gas, logU=logU,
                                logage=logage, logQ=logQ)

    neb_cont_y, neb_lines_y = vmap(
        lambda logQ_row: vmap(nebular_one)(csp._neb_ages_young, logQ_row)
    )(csp._neb_logqq_young)
    neb_young_ref = (neb_cont_y + neb_lines_y)[..., 0]

    n_z, n_age, n_wave = csp.flux.shape
    neb_all = jnp.zeros((n_z, n_age, n_wave), dtype=jnp.float32)
    neb_all = neb_all.at[:, csp._neb_young_idx, :].set(
        neb_young_ref.astype(jnp.float32))

    stellar_fluxes  = jnp.where(csp.kill_ion[None, :, :], 0.0, csp.flux)
    combined_fluxes = stellar_fluxes + neb_all

    attn, attn_diffuse = csp.attenuate_dust(csp.wave, theta)
    M        = csp._age_bin_mix
    tau_age  = jnp.einsum("ab,bw->aw", M, attn.astype(jnp.float32))
    attn_age = jnp.exp(-tau_age)

    W_f32    = W.astype(jnp.float32)
    spec_old = jnp.einsum("za,zaw,aw->w", W_f32, combined_fluxes, attn_age)
    spec_old = spec_old * jnp.exp(-attn_diffuse.astype(jnp.float32))
    spec_old = spec_old.reshape((-1,))

    rel_err    = jnp.abs(spec_new - spec_old) / (jnp.abs(spec_old) + 1e-30)
    max_re     = float(jnp.max(rel_err))
    mean_re    = float(jnp.mean(rel_err))
    median_re  = float(jnp.median(rel_err))

    # evaluate_batch is mathematically identical to the vmap path, so
    # differences should be at float32 rounding level.
    tol = 1e-5
    ok  = max_re < tol
    tag = "PASS" if ok else "FAIL"
    print(f"  [{tag}] max_rel  = {max_re:.2e}")
    print(f"         mean_rel = {mean_re:.2e}")
    print(f"         median   = {median_re:.2e}")
    print(f"         dtype(new) = {spec_new.dtype}  dtype(old) = {spec_old.dtype}")
    return ok


# ═══════════════════════════════════════════════════════════════════════════
# TEST 4: Timing
# ═══════════════════════════════════════════════════════════════════════════

def test_timing():
    backend = jax.default_backend()
    is_gpu  = backend.upper() in ("GPU", "CUDA")
    N_BENCH = 500 if is_gpu else 100  # shorter on CPU

    print("\n" + "=" * 70)
    print(f"TEST 4: Timing benchmarks  (backend = {backend}, N = {N_BENCH})")
    if not is_gpu:
        print("  NOTE: float32 vs float64 speedup is small on CPU.")
        print("        On A100 expect ~2x from float32 GEMV + nebular grid savings.")
    print("=" * 70)

    scenarios = [
        ("stellar only", dict(add_dust=False, add_diffuse_dust=False,
                              add_dust_emission=False, add_neb=False)),
        ("dust only",    dict(add_dust=True,  add_diffuse_dust=True,
                              add_dust_emission=False, add_neb=False)),
        ("neb only",     dict(add_dust=False, add_diffuse_dust=False,
                              add_dust_emission=False, add_neb=True)),
        ("dust + neb",   dict(add_dust=True,  add_diffuse_dust=True,
                              add_dust_emission=False, add_neb=True)),
    ]

    rng = np.random.default_rng(42)

    for label, kw in scenarios:
        csp   = make_csp(**kw)
        theta = _fill_theta(csp.theta_init)

        # ---- NEW path (evaluate_batch) --------------------------------------
        fn_new = jax.jit(csp.get_spectrum)
        _ = fn_new(theta).block_until_ready()           # compile

        times_new = np.empty(N_BENCH)
        for i in range(N_BENCH):
            t = theta.copy()
            if 'gas_logz' in t:
                t['gas_logz'] = jnp.array([float(rng.uniform(-1.0,  0.5))])
                t['gas_logu'] = jnp.array([float(rng.uniform(-4.0, -1.0))])
            if 'diffuse_tau_kc' in t:
                t['diffuse_tau_kc']     = float(rng.uniform(0.1, 4.0))
                t['diffuse_dust_index'] = float(rng.uniform(-1.5, 0.5))
            t0 = time.perf_counter()
            _ = fn_new(t).block_until_ready()
            times_new[i] = (time.perf_counter() - t0) * 1e3

        # ---- OLD path (nested vmap — only for nebular scenarios) ------------
        has_neb = kw.get('add_neb', False)
        if has_neb:
            # Build old-style vmap-based spectrum function
            def _old_neb_spectrum(theta_in, _csp=csp):
                W = _csp.calculate_ssp_weights(theta=theta_in)
                logZ_gas = theta_in["gas_logz"]
                logU_gas = theta_in["gas_logu"]

                def nebular_one(logage, logQ):
                    return _csp.neb.evaluate(
                        logZ=logZ_gas, logU=logU_gas,
                        logage=logage, logQ=logQ)

                neb_cont_y, neb_lines_y = vmap(
                    lambda logQ_row: vmap(nebular_one)(
                        _csp._neb_ages_young, logQ_row)
                )(_csp._neb_logqq_young)
                neb_young = (neb_cont_y + neb_lines_y)[..., 0]

                n_z, n_age, n_wave = _csp.flux.shape
                neb_all = jnp.zeros((n_z, n_age, n_wave), dtype=jnp.float32)
                neb_all = neb_all.at[:, _csp._neb_young_idx, :].set(
                    neb_young.astype(jnp.float32))
                stellar = jnp.where(_csp.kill_ion[None, :, :], 0.0, _csp.flux)
                combined = stellar + neb_all
                W_f32 = W.astype(jnp.float32)

                if hasattr(_csp, 'dust_attn'):
                    attn, attn_diff = _csp.attenuate_dust(_csp.wave, theta_in)
                    M = _csp._age_bin_mix
                    tau_age = jnp.einsum("ab,bw->aw", M, attn.astype(jnp.float32))
                    attn_age = jnp.exp(-tau_age)
                    spec = jnp.einsum("za,zaw,aw->w", W_f32, combined, attn_age)
                    spec = spec * jnp.exp(-attn_diff.astype(jnp.float32))
                else:
                    spec = jnp.einsum("za,zaw->w", W_f32, combined)
                return spec.reshape((-1,))

            fn_old = jax.jit(_old_neb_spectrum)
            _ = fn_old(theta).block_until_ready()       # compile

            rng_old = np.random.default_rng(42)         # same seed
            times_old = np.empty(N_BENCH)
            for i in range(N_BENCH):
                t = theta.copy()
                t['gas_logz'] = jnp.array([float(rng_old.uniform(-1.0,  0.5))])
                t['gas_logu'] = jnp.array([float(rng_old.uniform(-4.0, -1.0))])
                if 'diffuse_tau_kc' in t:
                    t['diffuse_tau_kc']     = float(rng_old.uniform(0.1, 4.0))
                    t['diffuse_dust_index'] = float(rng_old.uniform(-1.5, 0.5))
                t0 = time.perf_counter()
                _ = fn_old(t).block_until_ready()
                times_old[i] = (time.perf_counter() - t0) * 1e3

            speedup = times_old.mean() / times_new.mean()
            print(f"  {label:20s}  new {times_new.mean():7.2f} +/- {times_new.std():.2f} ms  |  "
                  f"old {times_old.mean():7.2f} +/- {times_old.std():.2f} ms  |  "
                  f"speedup {speedup:.2f}x")
        else:
            print(f"  {label:20s}  new {times_new.mean():7.2f} +/- {times_new.std():.2f} ms  |  "
                  f"(no nebular — old path identical)")


# ═══════════════════════════════════════════════════════════════════════════
# TEST 5: FSPS big_comparison
# ═══════════════════════════════════════════════════════════════════════════

def test_big_comparison_fsps():
    print("\n" + "=" * 70)
    print("TEST 5: big_comparison — FSPS validation")
    print("=" * 70)

    try:
        import fsps
    except ImportError:
        print("  [SKIP] python-fsps not installed — skipping FSPS comparison.")
        print("         Run the full big_comparison.py on Tursa instead.")
        return True

    sp = fsps.StellarPopulation(zcontinuous=0, zmet=1, sfh=3)
    sp.set_tabular_sfh(age=np.array(t_grid),
                       sfr=np.array(sfr_bimodal)[::-1])   # FSPS cosmic-time axis
    sp.params['dust_type'] = 4
    Z_solar = sp.zlegend[0]

    BASE_THETA_FSPS = {
        'lookback_time': lookback,
        'sfh':           sfr_bimodal,
        'Z':             jnp.array([jnp.log10(Z_solar)]),
    }

    def make_csp_fsps(**kw):
        return CSPBasis(
            ssp_data,
            theta             = BASE_THETA_FSPS.copy(),
            tuniv             = T_UNIV,
            tiny_logt         = -70,
            zh_const          = True,
            init_neb_params   = {'isoc_type': 'mist', 'cloudy_dust': False},
            init_dust_params  = DUST_BIN_PARAMS,
            diffuse_law       = 'kriek_conroy',
            sps_home          = SPS_HOME,
            verbose           = False,
            sfh_interp        = 'linear',
            **kw,
        )

    def fsps_spec(dust2=0.0, dust_index=0.0, dust1=0.0, dust1_index=0.0,
                  add_neb=False, add_duste=False,
                  gas_logz=GAS_LOGZ, gas_logu=GAS_LOGU):
        sp.params['dust2']             = dust2
        sp.params['dust_index']        = dust_index
        sp.params['dust1']             = dust1
        sp.params['dust1_index']       = dust1_index
        sp.params['add_neb_emission']  = add_neb
        sp.params['add_neb_continuum'] = add_neb
        sp.params['add_dust_emission'] = add_duste
        sp.params['gas_logz']          = gas_logz
        sp.params['gas_logu']          = gas_logu
        w, s = sp.get_spectrum(tage=T_UNIV)
        return w, s

    wave = jnp.array(ssp_data.ssp_wave)

    test_cases = [
        ("stellar only",
         dict(add_dust=False, add_diffuse_dust=False,
              add_dust_emission=False, add_neb=False),
         dict(), dict()),
        ("diffuse dust",
         dict(add_dust=True, add_diffuse_dust=True,
              add_dust_emission=False, add_neb=False),
         dict(diffuse_tau_kc=DIFFUSE_TAU, diffuse_dust_index=DIFFUSE_INDEX,
              tau_pow=0.0),
         dict(dust2=DIFFUSE_TAU, dust_index=DIFFUSE_INDEX)),
        ("nebular only",
         dict(add_dust=False, add_diffuse_dust=False,
              add_dust_emission=False, add_neb=True),
         dict(gas_logz=jnp.array([GAS_LOGZ]),
              gas_logu=jnp.array([GAS_LOGU])),
         dict(add_neb=True)),
        ("dust + neb",
         dict(add_dust=True, add_diffuse_dust=True,
              add_dust_emission=False, add_neb=True),
         dict(diffuse_tau_kc=DIFFUSE_TAU, diffuse_dust_index=DIFFUSE_INDEX,
              tau_pow=2.0, alpha=-1.0,
              gas_logz=jnp.array([GAS_LOGZ]),
              gas_logu=jnp.array([GAS_LOGU])),
         dict(dust2=DIFFUSE_TAU, dust_index=DIFFUSE_INDEX,
              dust1=2.0, dust1_index=-1.0, add_neb=True)),
    ]

    all_pass = True
    for label, csp_kw, theta_upd, fsps_kw in test_cases:
        csp   = make_csp_fsps(**csp_kw)
        theta = csp.theta_init.copy()
        theta.update(theta_upd)

        spec_cer = csp.get_spectrum(theta)
        w_fsps, s_fsps = fsps_spec(**fsps_kw)

        band      = slice(50, 400)
        flux_fsps = float(jnp.trapezoid(jnp.array(s_fsps)[band], jnp.array(w_fsps)[band]))
        flux_cer  = float(jnp.trapezoid(spec_cer[band], wave[band]))
        pct       = abs(flux_fsps - flux_cer) / flux_fsps * 100

        tol = 2.0
        ok  = pct < tol
        tag = "PASS" if ok else "FAIL"
        if not ok:
            all_pass = False
        print(f"  [{tag}] {label:25s}  flux diff = {pct:.3f} %")

    return all_pass


# ═══════════════════════════════════════════════════════════════════════════
# TEST 6: Gradient correctness
# ═══════════════════════════════════════════════════════════════════════════

def test_gradients():
    print("\n" + "=" * 70)
    print("TEST 6: Gradient correctness (jax.grad through optimised path)")
    print("=" * 70)

    csp   = make_csp(add_dust=True, add_diffuse_dust=True,
                     add_dust_emission=False, add_neb=True)
    theta = _fill_theta(csp.theta_init)

    # grad w.r.t. diffuse_tau_kc
    def loss_tau(tau_kc):
        t = theta.copy()
        t['diffuse_tau_kc'] = tau_kc
        return jnp.sum(csp.get_spectrum(t))

    g_tau = jax.jit(jax.grad(loss_tau))(jnp.float32(DIFFUSE_TAU))
    ok_tau = bool(jnp.isfinite(g_tau) & (jnp.abs(g_tau) > 1e-20))
    tag_tau = "PASS" if ok_tau else "FAIL"
    print(f"  [{tag_tau}] d(sum spec)/d(tau_kc) = {float(g_tau):.6e}")

    # grad w.r.t. gas_logz  (flows through evaluate_batch interpolation)
    def loss_logz(logz):
        t = theta.copy()
        t['gas_logz'] = logz.reshape(1)
        return jnp.sum(csp.get_spectrum(t))

    g_logz = jax.jit(jax.grad(loss_logz))(jnp.float32(GAS_LOGZ))
    ok_logz = bool(jnp.isfinite(g_logz) & (jnp.abs(g_logz) > 1e-20))
    tag_logz = "PASS" if ok_logz else "FAIL"
    print(f"  [{tag_logz}] d(sum spec)/d(gas_logz) = {float(g_logz):.6e}")

    # grad w.r.t. gas_logu  (also through evaluate_batch)
    def loss_logu(logu):
        t = theta.copy()
        t['gas_logu'] = logu.reshape(1)
        return jnp.sum(csp.get_spectrum(t))

    g_logu = jax.jit(jax.grad(loss_logu))(jnp.float32(GAS_LOGU))
    ok_logu = bool(jnp.isfinite(g_logu) & (jnp.abs(g_logu) > 1e-20))
    tag_logu = "PASS" if ok_logu else "FAIL"
    print(f"  [{tag_logu}] d(sum spec)/d(gas_logu) = {float(g_logu):.6e}")

    return ok_tau and ok_logz and ok_logu


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    backend = jax.default_backend()
    devices = jax.devices()

    print("=" * 70)
    print("ceridwen float32 + nebular evaluate_batch optimisation tests")
    print(f"  platform : {platform.system()} {platform.machine()}")
    print(f"  backend  : {backend}")
    print(f"  devices  : {devices}")
    print(f"  x64      : {jax.config.jax_enable_x64}")
    print("=" * 70)

    results = {}
    results["dtype"]     = test_output_dtype()
    results["neb_batch"] = test_nebular_batch_accuracy()
    results["precision"] = test_precision_comparison()
    test_timing()                                       # informational
    results["fsps"]      = test_big_comparison_fsps()
    results["gradients"] = test_gradients()

    # ── Summary ──────────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    all_pass = True
    for name, ok in results.items():
        tag = "PASS" if ok else "FAIL"
        if not ok:
            all_pass = False
        print(f"  {name:20s} : {tag}")

    if all_pass:
        print("\nAll tests passed.")
    else:
        print("\nSome tests FAILED.")
        sys.exit(1)
